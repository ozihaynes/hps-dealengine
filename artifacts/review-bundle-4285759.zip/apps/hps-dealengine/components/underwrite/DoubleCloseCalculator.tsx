import React from 'react';
import { GlassCard, Button, InputField, SelectField, ToggleSwitch, Badge } from '../ui';
import { DoubleClose } from '../../services/engine';
import { fmt$ } from '../../utils/helpers';
import type { Deal, EngineCalculations } from '../../types';

interface DoubleCloseCalculatorProps {
  deal: Deal;
  calc: EngineCalculations;
  setDealValue: (path: string, value: any) => void;
}

const DoubleCloseCalculator: React.FC<DoubleCloseCalculatorProps> = ({
  deal,
  calc,
  setDealValue,
}) => {
  const setDC = (k: string, v: any) => setDealValue(`costs.double_close.${k}`, v);
  const dc = (deal as any).costs?.double_close || {};
  const dcCalcs = DoubleClose.computeDoubleClose(dc, { deal });

  const doAutofill = () => {
    const filled = DoubleClose.autofill(dc, { deal }, calc);
    setDealValue('costs.double_close', filled);
  };

  const isSimple = !!dc.use_simple_mode;

  return (
    <div className="space-y-4 mt-3">
      <GlassCard className="p-4 md:p-5">
        <div className="flex items-center justify-between">
          <div className="label-xs uppercase">Double Close Tools</div>
          <div className="flex items-center gap-3">
            <ToggleSwitch
              label={isSimple ? 'Simple' : 'Advanced'}
              checked={isSimple}
              onChange={() => setDC('use_simple_mode', !isSimple)}
            />
            <Button size="sm" onClick={doAutofill}>
              Autofill from deal
            </Button>
          </div>
        </div>
      </GlassCard>

      {isSimple ? (
        <GlassCard className="p-5 md:p-6 space-y-3">
          <h4 className="label-xs uppercase">Simple Mode - Core Inputs</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
            <SelectField
              label="County"
              value={dc.county || 'Orange'}
              onChange={(e) => setDC('county', e.target.value)}
            >
              <option>Orange</option>
              <option>Osceola</option>
              <option>Polk</option>
              <option>Miami-Dade</option>
            </SelectField>
            <InputField
              label="A–B Price (Pab)"
              type="number"
              prefix="$"
              value={Number.isFinite(dc.pab) ? dc.pab : ''}
              onChange={(e) => setDC('pab', e.target.value)}
              placeholder="Enter Price"
            />
            <InputField
              label="B–C Price (Pbc)"
              type="number"
              prefix="$"
              value={Number.isFinite(dc.pbc) ? dc.pbc : ''}
              onChange={(e) => setDC('pbc', e.target.value)}
              placeholder="Enter Price"
            />
            <SelectField
              label="Structure"
              value={dc.type || 'Same-day'}
              onChange={(e) => setDC('type', e.target.value)}
            >
              <option>Same-day</option>
              <option>Held-days</option>
            </SelectField>
            <InputField
              label="Days Held"
              type="number"
              value={dc.type === 'Same-day' ? 0 : dc.days_held || ''}
              onChange={(e) => setDC('days_held', e.target.value)}
              disabled={dc.type === 'Same-day'}
            />
            <ToggleSwitch
              label="Using Transactional Funding?"
              checked={!!dc.using_tf}
              onChange={() => setDC('using_tf', !dc.using_tf)}
            />
            {dc.using_tf && (
              <>
                <InputField
                  label="TF Principal"
                  type="number"
                  prefix="$"
                  value={Number.isFinite(dc.tf_principal) ? dc.tf_principal : ''}
                  onChange={(e) => setDC('tf_principal', e.target.value)}
                  placeholder="Enter Amount"
                />
                <InputField
                  label="TF Points (e.g., 0.02)"
                  value={dc.tf_points_rate || ''}
                  onChange={(e) => setDC('tf_points_rate', e.target.value)}
                />
              </>
            )}
            <SelectField
              label="HOA/Condo Present?"
              value={dc.association_present || 'No'}
              onChange={(e) => setDC('association_present', e.target.value)}
            >
              <option>No</option>
              <option>Yes-HOA</option>
              <option>Yes-Condo</option>
            </SelectField>
            {dc.association_present !== 'No' && (
              <SelectField
                label="Rush Estoppel?"
                value={dc.rush_estoppel || 'No'}
                onChange={(e) => setDC('rush_estoppel', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
              </SelectField>
            )}
          </div>
        </GlassCard>
      ) : (
        <>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">A) Property & County</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <SelectField
                label="County"
                value={dc.county || 'Orange'}
                onChange={(e) => setDC('county', e.target.value)}
              >
                <option>Orange</option>
                <option>Osceola</option>
                <option>Polk</option>
              </SelectField>
              <SelectField
                label="Property Type"
                value={dc.property_type || 'SFR'}
                onChange={(e) => setDC('property_type', e.target.value)}
              >
                <option>SFR</option>
                <option>Townhome</option>
                <option>Condo</option>
                <option>Duplex/2-4</option>
                <option>Mobile on land</option>
                <option>Vacant land</option>
              </SelectField>
              <SelectField
                label="HOA/Condo Present"
                value={dc.association_present || 'No'}
                onChange={(e) => setDC('association_present', e.target.value)}
              >
                <option>No</option>
                <option>Yes-HOA</option>
                <option>Yes-Condo</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">B) Structure & Timing</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <SelectField
                label="Double-close type"
                value={dc.type || 'Same-day'}
                onChange={(e) => setDC('type', e.target.value)}
              >
                <option>Same-day</option>
                <option>Held-days</option>
              </SelectField>
              <InputField
                label="Days held (A-B → B-C)"
                type="number"
                value={dc.days_held || ''}
                onChange={(e) => setDC('days_held', e.target.value)}
              />
              <SelectField
                label="Same-day order (if applicable)"
                value={dc.same_day_order || 'No preference'}
                onChange={(e) => setDC('same_day_order', e.target.value)}
              >
                <option>No preference</option>
                <option>A-B AM / B-C PM</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">C) A-B (you BUY from seller)</h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <InputField
                label="Pab"
                type="number"
                prefix="$"
                value={Number.isFinite(dc.pab) ? dc.pab : ''}
                onChange={(e) => setDC('pab', e.target.value)}
                placeholder="Enter Price"
              />
              <InputField
                label="Title/settlement A-B"
                type="number"
                prefix="$"
                value={dc.title_ab || ''}
                onChange={(e) => setDC('title_ab', e.target.value)}
              />
              <InputField
                label="Other fees A-B"
                type="number"
                prefix="$"
                value={dc.other_ab || ''}
                onChange={(e) => setDC('other_ab', e.target.value)}
              />
              <SelectField
                label="Owner's title policy paid by (A-B)"
                value={dc.owners_title_payer_ab || 'Unknown'}
                onChange={(e) => setDC('owners_title_payer_ab', e.target.value)}
              >
                <option>Seller</option>
                <option>You</option>
                <option>Unknown</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">D) B-C (you SELL to end-buyer)</h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <InputField
                label="Pbc"
                type="number"
                prefix="$"
                value={Number.isFinite(dc.pbc) ? dc.pbc : ''}
                onChange={(e) => setDC('pbc', e.target.value)}
                placeholder="Enter Price"
              />
              <InputField
                label="Title/settlement B-C"
                type="number"
                prefix="$"
                value={dc.title_bc || ''}
                onChange={(e) => setDC('title_bc', e.target.value)}
              />
              <InputField
                label="Other fees B-C"
                type="number"
                prefix="$"
                value={dc.other_bc || ''}
                onChange={(e) => setDC('other_bc', e.target.value)}
              />
              <SelectField
                label="Owner's title policy paid by (B-C)"
                value={dc.owners_title_payer_bc || 'Unknown'}
                onChange={(e) => setDC('owners_title_payer_bc', e.target.value)}
              >
                <option>You</option>
                <option>End buyer</option>
                <option>Unknown</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">E) End-buyer funds</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <SelectField
                label="Buyer funds"
                value={dc.buyer_funds || 'Cash'}
                onChange={(e) => setDC('buyer_funds', e.target.value)}
              >
                <option>Cash</option>
                <option>Conventional</option>
                <option>DSCR/Investor</option>
                <option>Hard money</option>
                <option>FHA</option>
                <option>VA</option>
              </SelectField>
              <SelectField
                label="Lender known"
                value={dc.lender_known || 'N/A'}
                onChange={(e) => setDC('lender_known', e.target.value)}
              >
                <option>N/A</option>
                <option>Yes</option>
                <option>No</option>
              </SelectField>
              <InputField
                label="ARV (for fee check)"
                type="number"
                prefix="$"
                value={dc.arv_for_fee_check || (deal as any).market?.arv || ''}
                onChange={(e) => setDC('arv_for_fee_check', e.target.value)}
              />
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">F) Transactional Funding (A-B)</h4>
            <div className="grid grid-cols-1 md:grid-cols-6 gap-3 items-end">
              <ToggleSwitch
                label="Using Transactional Funding?"
                checked={!!dc.using_tf}
                onChange={() => setDC('using_tf', !dc.using_tf)}
              />
              <InputField
                label="TF principal"
                type="number"
                prefix="$"
                value={Number.isFinite(dc.tf_principal) ? dc.tf_principal : ''}
                onChange={(e) => setDC('tf_principal', e.target.value)}
                placeholder="Enter Amount"
              />
              <InputField
                label="TF points rate"
                type="number"
                placeholder="e.g., 0.02"
                value={dc.tf_points_rate || ''}
                onChange={(e) => setDC('tf_points_rate', e.target.value)}
              />
              <SelectField
                label="Note executed in FL?"
                value={dc.tf_note_executed_fl || 'No'}
                onChange={(e) => setDC('tf_note_executed_fl', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
                <option>Unsure</option>
              </SelectField>
              <SelectField
                label="Note secured by property?"
                value={dc.tf_secured || 'No'}
                onChange={(e) => setDC('tf_secured', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
                <option>Unsure</option>
              </SelectField>
              <InputField
                label="TF extra fees"
                type="number"
                prefix="$"
                value={dc.tf_extra_fees || ''}
                onChange={(e) => setDC('tf_extra_fees', e.target.value)}
              />
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">G) HOA / Condo (if applicable)</h4>
            <div className="grid grid-cols-1 md:grid-cols-5 gap-3">
              <SelectField
                label="Association type"
                value={dc.association_type || 'HOA'}
                onChange={(e) => setDC('association_type', e.target.value)}
              >
                <option>HOA</option>
                <option>Condo</option>
                <option>N/A</option>
              </SelectField>
              <InputField
                label="Estoppel fee"
                type="number"
                prefix="$"
                value={dc.estoppel_fee || ''}
                onChange={(e) => setDC('estoppel_fee', e.target.value)}
              />
              <SelectField
                label="Rush estoppel ordered"
                value={dc.rush_estoppel || 'No'}
                onChange={(e) => setDC('rush_estoppel', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
              </SelectField>
              <InputField
                label="Transfer/application fees"
                type="number"
                prefix="$"
                value={dc.transfer_fees || ''}
                onChange={(e) => setDC('transfer_fees', e.target.value)}
              />
              <SelectField
                label="Board approval pre-closing"
                value={dc.board_approval || 'No'}
                onChange={(e) => setDC('board_approval', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
                <option>Unsure</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">H) Carry (if not same-day)</h4>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
              <InputField
                label="Carry / holding cost"
                type="number"
                prefix="$"
                value={dc.carry_amount || ''}
                onChange={(e) => setDC('carry_amount', e.target.value)}
              />
              <SelectField
                label="Carry basis"
                value={dc.carry_basis || 'day'}
                onChange={(e) => setDC('carry_basis', e.target.value)}
              >
                <option>day</option>
                <option>month</option>
              </SelectField>
              <InputField
                label="Days held (again)"
                type="number"
                value={dc.days_held || ''}
                onChange={(e) => setDC('days_held', e.target.value)}
              />
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">I) Targets & Estimation</h4>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
              <InputField
                label="Minimum acceptable net spread (optional)"
                type="number"
                prefix="$"
                value={dc.min_net_spread || ''}
                onChange={(e) => setDC('min_net_spread', e.target.value)}
              />
              <SelectField
                label="Estimate with FL promulgated rates if missing?"
                value={dc.use_promulgated_estimates || 'No'}
                onChange={(e) => setDC('use_promulgated_estimates', e.target.value)}
              >
                <option>No</option>
                <option>Yes</option>
              </SelectField>
              <SelectField
                label="Assume owner's title payer A-B"
                value={dc.assumed_owner_payer_ab || 'Unknown'}
                onChange={(e) => setDC('assumed_owner_payer_ab', e.target.value)}
              >
                <option>Unknown</option>
                <option>Seller</option>
                <option>You</option>
              </SelectField>
              <SelectField
                label="Assume owner's title payer B-C"
                value={dc.assumed_owner_payer_bc || 'Unknown'}
                onChange={(e) => setDC('assumed_owner_payer_bc', e.target.value)}
              >
                <option>Unknown</option>
                <option>You</option>
                <option>End buyer</option>
              </SelectField>
            </div>
          </GlassCard>
          <GlassCard className="p-5 md:p-6 space-y-3">
            <h4 className="label-xs uppercase">J) Outputs & Apply</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-3 items-end">
              <ToggleSwitch
                label="Show items 1-13 full math"
                checked={dc.show_items_math === undefined ? true : !!dc.show_items_math}
                onChange={() => setDC('show_items_math', !dc.show_items_math)}
              />
              <ToggleSwitch
                label="Show fee target check"
                checked={dc.show_fee_target === undefined ? true : !!dc.show_fee_target}
                onChange={() => setDC('show_fee_target', !dc.show_fee_target)}
              />
              <ToggleSwitch
                label="Show FHA/VA 90-day flag"
                checked={dc.show_90d_flag === undefined ? true : !!dc.show_90d_flag}
                onChange={() => setDC('show_90d_flag', !dc.show_90d_flag)}
              />
              <ToggleSwitch
                label="Show notes/assumptions"
                checked={dc.show_notes === undefined ? true : !!dc.show_notes}
                onChange={() => setDC('show_notes', !dc.show_notes)}
              />
            </div>
          </GlassCard>
        </>
      )}

      <GlassCard className="p-5 md:p-6 space-y-3">
        <h3 className="text-text-primary font-semibold text-base">Double-Close Results</h3>
        {(dc.show_items_math === undefined || dc.show_items_math) && (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="info-card space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span>Deed Stamps (A-B)</span>
                <span className="font-semibold">{fmt$(dcCalcs.Deed_Stamps_AB, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Deed Stamps (B-C)</span>
                <span className="font-semibold">{fmt$(dcCalcs.Deed_Stamps_BC, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Title/Settlement A-B</span>
                <span className="font-semibold">{fmt$(dcCalcs.Title_AB, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Title/Settlement B-C</span>
                <span className="font-semibold">{fmt$(dcCalcs.Title_BC, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Other A-B</span>
                <span className="font-semibold">{fmt$(dcCalcs.Other_AB, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Other B-C</span>
                <span className="font-semibold">{fmt$(dcCalcs.Other_BC, 0)}</span>
              </div>
            </div>
            <div className="info-card space-y-1.5 text-sm">
              <div className="flex justify-between">
                <span>TF Points ($)</span>
                <span className="font-semibold">{fmt$(dcCalcs.TF_Points_$, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Doc Stamps on Note</span>
                <span className="font-semibold">{fmt$(dcCalcs.DocStamps_Note, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Intangible Tax</span>
                <span className="font-semibold">{fmt$(dcCalcs.Intangible_Tax, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Carry (daily)</span>
                <span className="font-semibold">{fmt$(dcCalcs.Carry_Daily, 0)}</span>
              </div>
              <div className="flex justify-between">
                <span>Carry (total)</span>
                <span className="font-semibold">{fmt$(dcCalcs.Carry_Total, 0)}</span>
              </div>
            </div>
          </div>
        )}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          <div className="highlight-card flex items-center justify-between">
            <span className="font-semibold text-text-secondary">Extra Closing Load</span>
            <span className="text-lg font-extrabold">{fmt$(dcCalcs.Extra_Closing_Load, 0)}</span>
          </div>
          <div className="info-card space-y-1.5 text-sm">
            <div className="flex justify-between">
              <span>Gross Spread (Pbc - Pab)</span>
              <span className="font-semibold">{fmt$(dcCalcs.Gross_Spread, 0)}</span>
            </div>
            <div className="flex justify-between">
              <span>Net Spread (before carry)</span>
              <span className="font-semibold">{fmt$(dcCalcs.Net_Spread_Before_Carry, 0)}</span>
            </div>
            <div className="flex justify-between">
              <span>Net Spread (after carry)</span>
              <span className="font-semibold">{fmt$(dcCalcs.Net_Spread_After_Carry, 0)}</span>
            </div>
          </div>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
          {(dc.show_fee_target === undefined || dc.show_fee_target) && (
            <div className="info-card text-sm flex items-center justify-between">
              <div>
                <div className="label-xs">Fee Target (≈ 3% of ARV)</div>
                <div>
                  Threshold:{' '}
                  <span className="font-semibold">{fmt$(dcCalcs.Fee_Target_Threshold, 0)}</span>
                </div>
              </div>
              <Badge
                color={
                  dcCalcs.Fee_Target_Check === 'YES'
                    ? 'green'
                    : dcCalcs.Fee_Target_Check === 'NO'
                    ? 'orange'
                    : 'blue'
                }
              >
                {dcCalcs.Fee_Target_Check}
              </Badge>
            </div>
          )}
          {(dc.show_90d_flag === undefined || dc.show_90d_flag) && (
            <div className="info-card text-sm flex items-center justify-between">
              <div className="label-xs">FHA/VA 90-Day Seasoning</div>
              <Badge color={dcCalcs.Seasoning_Flag.startsWith('HIGH') ? 'orange' : 'green'}>
                {dcCalcs.Seasoning_Flag}
              </Badge>
            </div>
          )}
        </div>
        {(dc.show_notes === undefined || dc.show_notes) && (
          <div className="info-card text-xs text-text-secondary/80">
            <div className="label-xs mb-1">Notes / Assumptions</div>
            <ul className="list-disc pl-5 space-y-1">
              {dcCalcs.notes.map((n: string, i: number) => (
                <li key={i}>{n}</li>
              ))}
            </ul>
          </div>
        )}
      </GlassCard>
    </div>
  );
};

export default DoubleCloseCalculator;
