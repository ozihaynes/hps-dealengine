# Smoke script (sanitized, no secrets)

# Requires env vars:
# - HPS_SMOKE_EMAIL
# - HPS_SMOKE_PASSWORD

# Steps:
# 1) supabase projects api-keys --project-ref zjkihnihhqmnhpxkecpy --output json
# 2) POST auth/v1/token?grant_type=password with anon key and HPS_SMOKE_EMAIL/PASSWORD
# 3) POST functions/v1/v1-deal-task-states with { op: \"list\", deal_id: \"f84bab8d-e377-4512-a4c8-0821c23a82ea\" }
# 4) Hash response1/response2 and compare
