


SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;


CREATE SCHEMA IF NOT EXISTS "public";


ALTER SCHEMA "public" OWNER TO "pg_database_owner";


COMMENT ON SCHEMA "public" IS 'standard public schema';



CREATE TYPE "public"."deal_workflow_event_type" AS ENUM (
    'UNDERWRITING_COMPLETE'
);


ALTER TYPE "public"."deal_workflow_event_type" OWNER TO "postgres";


CREATE TYPE "public"."membership_role" AS ENUM (
    'analyst',
    'manager',
    'vp',
    'owner'
);


ALTER TYPE "public"."membership_role" OWNER TO "postgres";


CREATE TYPE "public"."policy_override_status" AS ENUM (
    'pending',
    'approved',
    'rejected'
);


ALTER TYPE "public"."policy_override_status" OWNER TO "postgres";


CREATE TYPE "public"."policy_posture" AS ENUM (
    'conservative',
    'base',
    'aggressive'
);


ALTER TYPE "public"."policy_posture" OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."_ensure_policy_cmd"("_name" "text", "_table" "regclass", "_cmd" "text", "_using" "text", "_check" "text") RETURNS "void"
    LANGUAGE "plpgsql"
    AS $$
  DECLARE exists_policy boolean;
          sql           text;
          c             text := upper(_cmd);
  BEGIN
    SELECT EXISTS (
      SELECT 1 FROM pg_catalog.pg_policies
      WHERE schemaname = 'public'
        AND tablename  = split_part(_table::text, '.', 2)
        AND policyname = _name
    ) INTO exists_policy;

    IF NOT exists_policy THEN
      IF c IN ('SELECT','DELETE') THEN
        -- SELECT/DELETE: USING only
        sql := format('CREATE POLICY %I ON %s FOR %s USING (%s)',
                      _name, _table, _cmd, COALESCE(_using,'true'));
      ELSIF c = 'INSERT' THEN
        -- INSERT: CHECK only
        sql := format('CREATE POLICY %I ON %s FOR %s WITH CHECK (%s)',
                      _name, _table, _cmd, COALESCE(_check,'true'));
      ELSIF c = 'UPDATE' THEN
        -- UPDATE: USING + CHECK
        sql := format('CREATE POLICY %I ON %s FOR %s USING (%s) WITH CHECK (%s)',
                      _name, _table, _cmd, COALESCE(_using,'true'), COALESCE(_check,'true'));
      ELSE
        RAISE EXCEPTION 'Unsupported command % for CREATE POLICY', _cmd;
      END IF;
      EXECUTE sql;
    END IF;
  END;
  $$;


ALTER FUNCTION "public"."_ensure_policy_cmd"("_name" "text", "_table" "regclass", "_cmd" "text", "_using" "text", "_check" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."audit_log_row_change"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
declare
  v_org uuid;
  v_row uuid;
  v_old jsonb;
  v_new jsonb;
begin
  if TG_OP = 'DELETE' then
    begin v_org := OLD.org_id; exception when others then v_org := null; end;
    begin v_row := OLD.id;     exception when others then v_row := null; end;
    v_old := to_jsonb(OLD);
    v_new := null;
  else
    begin v_org := NEW.org_id; exception when others then v_org := null; end;
    begin v_row := NEW.id;     exception when others then v_row := null; end;
    v_old := case when TG_OP='UPDATE' then to_jsonb(OLD) else null end;
    v_new := to_jsonb(NEW);
  end if;

  insert into public.audit_logs(
    org_id,
    actor_user_id,
    table_name,
    entity,
    row_id_uuid,
    action,
    diff
  )
  values (
    v_org,
    auth.uid(),
    TG_TABLE_NAME,
    TG_TABLE_NAME,
    v_row,
    TG_OP,
    jsonb_build_object('old', v_old, 'new', v_new)
  );

  return case when TG_OP='DELETE' then OLD else NEW end;
end
$$;


ALTER FUNCTION "public"."audit_log_row_change"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."dbg_claim"("claim" "text") RETURNS "text"
    LANGUAGE "sql" STABLE SECURITY DEFINER
    AS $$
  SELECT current_setting('request.jwt.claims', true)::jsonb ->> claim
$$;


ALTER FUNCTION "public"."dbg_claim"("claim" "text") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."dbg_uid"() RETURNS "uuid"
    LANGUAGE "sql" STABLE
    AS $$ select auth.uid() $$;


ALTER FUNCTION "public"."dbg_uid"() OWNER TO "postgres";


COMMENT ON FUNCTION "public"."dbg_uid"() IS 'Returns caller JWT sub (uuid) for PostgREST debugging.';



CREATE OR REPLACE FUNCTION "public"."debug_auth_context"() RETURNS "jsonb"
    LANGUAGE "sql" STABLE
    AS $$
  select jsonb_build_object(
    'uid', auth.uid(),
    'role', current_setting('request.jwt.claim.role', true),
    'sub',  current_setting('request.jwt.claim.sub', true),
    'claims', current_setting('request.jwt.claims', true)
  );
$$;


ALTER FUNCTION "public"."debug_auth_context"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."delete_expired_ai_chat"() RETURNS "void"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
begin
  delete from public.ai_chat_threads where expires_at < now();
end
$$;


ALTER FUNCTION "public"."delete_expired_ai_chat"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."ensure_membership_for_self_vp"() RETURNS "uuid"
    LANGUAGE "plpgsql" SECURITY DEFINER
    AS $$
declare
  v_org uuid;
begin
  select org_id into v_org from public._default_org limit 1;
  if v_org is null then
    insert into public.organizations(name) values ('HPS DealEngine') returning id into v_org;
  end if;

  insert into public.memberships(org_id, user_id, role)
  values (v_org, auth.uid(), 'vp')
  on conflict (org_id, user_id) do update set role = excluded.role;

  return v_org;
end
$$;


ALTER FUNCTION "public"."ensure_membership_for_self_vp"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."export_schema_ddl"() RETURNS "text"
    LANGUAGE "plpgsql"
    AS $$
declare
  ddl text := '';
begin
  -- Schemas
  ddl := ddl || '-- Schemas' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format('CREATE SCHEMA IF NOT EXISTS %I;', n.nspname), E'\n')
    from pg_namespace n
    where n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Enum types
  ddl := ddl || '-- Enum types' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'CREATE TYPE %I.%I AS ENUM (%s);',
      n.nspname, t.typname,
      (select string_agg(quote_literal(e.enumlabel), ', ' order by e.enumsortorder)
       from pg_enum e where e.enumtypid = t.oid)
    ), E'\n')
    from pg_type t
    join pg_namespace n on n.oid = t.typnamespace
    where t.typtype = 'e'
      and n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Sequences (pg_sequences has increment_by / cache_size / min/max / cycle)
  ddl := ddl || '-- Sequences' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'CREATE SEQUENCE %I.%I START %s INCREMENT %s MINVALUE %s MAXVALUE %s CACHE %s%s;',
      s.schemaname, s.sequencename, s.start_value, s.increment_by, s.min_value, s.max_value, s.cache_size,
      case when s.cycle then ' CYCLE' else '' end
    ), E'\n')
    from pg_sequences s
    where s.schemaname not in ('pg_catalog','information_schema')
  ), '-- (none)') || E'\n\n';

  -- Tables (columns only; constraints & indexes below)
  ddl := ddl || '-- Tables' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'CREATE TABLE IF NOT EXISTS %I.%I (%s);',
      ns.nspname, c.relname,
      (
        select string_agg(coldef, E',\n  ' order by attnum)
        from (
          select
            a.attnum,
            format(
              '%I %s%s%s',
              a.attname,
              pg_catalog.format_type(a.atttypid, a.atttypmod),
              case when a.attidentity <> '' then
                format(' GENERATED %s AS IDENTITY',
                       case a.attidentity when 'a' then 'ALWAYS' else 'BY DEFAULT' end)
              else '' end,
              case
                when ad.adbin is not null and a.attidentity = '' then
                  ' DEFAULT ' || pg_get_expr(ad.adbin, ad.adrelid)
                else '' end
              || case when a.attnotnull then ' NOT NULL' else '' end
            ) as coldef
          from pg_attribute a
          left join pg_attrdef ad
            on ad.adrelid = a.attrelid and ad.adnum = a.attnum
          where a.attrelid = c.oid
            and a.attnum > 0
            and not a.attisdropped
        ) cols
      )
    ), E'\n\n')
    from pg_class c
    join pg_namespace ns on ns.oid = c.relnamespace
    where c.relkind in ('r','p')  -- tables + partitioned tables
      and ns.nspname not like 'pg_%' and ns.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Constraints
  ddl := ddl || '-- Constraints' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'ALTER TABLE ONLY %I.%I ADD CONSTRAINT %I %s;',
      n.nspname, c.relname, con.conname, pg_get_constraintdef(con.oid, true)
    ), E'\n')
    from pg_constraint con
    join pg_class c on c.oid = con.conrelid
    join pg_namespace n on n.oid = c.relnamespace
    where n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Indexes (exclude constraint-backed)
  ddl := ddl || '-- Indexes' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(pg_get_indexdef(i.indexrelid), E';\n') || ';'
    from pg_index i
    join pg_class t on t.oid = i.indrelid
    join pg_namespace n on n.oid = t.relnamespace
    where n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
      and i.indexrelid not in (select conindid from pg_constraint where conindid <> 0)
  ), '-- (none)') || E'\n\n';

  -- Views
  ddl := ddl || '-- Views' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'CREATE OR REPLACE VIEW %I.%I AS %s',
      v.schemaname, v.viewname,
      pg_get_viewdef((quote_ident(v.schemaname)||'.'||quote_ident(v.viewname))::regclass, true)
    ), E';\n') || ';'
    from pg_views v
    where v.schemaname not like 'pg_%' and v.schemaname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Materialized views
  ddl := ddl || '-- Materialized views' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'CREATE MATERIALIZED VIEW IF NOT EXISTS %I.%I AS %s;',
      m.schemaname, m.matviewname, m.definition
    ), E'\n')
    from pg_matviews m
    where m.schemaname not like 'pg_%' and m.schemaname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Functions (user-defined)
  ddl := ddl || '-- Functions' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(pg_get_functiondef(p.oid), E'\n\n')
    from pg_proc p
    join pg_namespace n on n.oid = p.pronamespace
    where n.nspname not in ('pg_catalog','information_schema')
  ), '-- (none)') || E'\n\n';

  -- Triggers
  ddl := ddl || '-- Triggers' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(pg_get_triggerdef(t.oid, true) || ';', E'\n')
    from pg_trigger t
    join pg_class c on c.oid = t.tgrelid
    join pg_namespace n on n.oid = c.relnamespace
    where not t.tgisinternal
      and n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- Grants (tables)
  ddl := ddl || '-- Grants (tables)' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'GRANT %s ON TABLE %I.%I TO %I;',
      privilege_type, table_schema, table_name, grantee
    ), E'\n')
    from information_schema.role_table_grants
    where table_schema not in ('pg_catalog','information_schema')
  ), '-- (none)') || E'\n\n';

  -- RLS enable/force
  ddl := ddl || '-- RLS enable/force' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(format(
      'ALTER TABLE %I.%I %s ROW LEVEL SECURITY%s;',
      n.nspname, c.relname,
      case when c.relrowsecurity then 'ENABLE' else 'DISABLE' end,
      case when c.relforcerowsecurity then ' FORCE' else '' end
    ), E'\n')
    from pg_class c
    join pg_namespace n on n.oid = c.relnamespace
    where c.relkind = 'r'
      and n.nspname not like 'pg_%' and n.nspname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  -- RLS policies
  ddl := ddl || '-- RLS policies' || E'\n';
  ddl := ddl || coalesce((
    select string_agg(
      format(
        'CREATE POLICY %I ON %I.%I FOR %s TO %s%s%s;',
        pol.policyname,
        pol.schemaname, pol.tablename,
        lower(pol.cmd),
        case when pol.roles is null
             then 'public'
             else array_to_string(ARRAY(select quote_ident(r) from unnest(pol.roles) as r), ', ')
        end,
        case when pol.qual is null then '' else E' USING ('||pol.qual||')' end,
        case when pol.with_check is null then '' else E' WITH CHECK ('||pol.with_check||')' end
      )
    , E'\n')
    from pg_policies pol
    where pol.schemaname not like 'pg_%' and pol.schemaname <> 'information_schema'
  ), '-- (none)') || E'\n\n';

  return ddl;
end
$$;


ALTER FUNCTION "public"."export_schema_ddl"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."get_caller_org"() RETURNS "uuid"
    LANGUAGE "sql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select m.org_id
  from public.memberships m
  where m.user_id = auth.uid()
  order by m.created_at desc
  limit 1;
$$;


ALTER FUNCTION "public"."get_caller_org"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_member_of"("p_org" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1
    from public.memberships m
    where m.org_id = p_org
      and m.user_id = auth.uid()
  );
$$;


ALTER FUNCTION "public"."is_member_of"("p_org" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_org_manager"("p_org" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1
    from public.memberships m
    where m.org_id = p_org
      and m.user_id = auth.uid()
      and m.role in ('manager'::membership_role, 'vp'::membership_role)
  );
$$;


ALTER FUNCTION "public"."is_org_manager"("p_org" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_org_manager"("_org" "uuid", "_uid" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1
    from public.memberships
    where org_id = _org
      and user_id = _uid
      and role in ('manager','vp')
  );
$$;


ALTER FUNCTION "public"."is_org_manager"("_org" "uuid", "_uid" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."is_org_member"("_org" "uuid", "_uid" "uuid") RETURNS boolean
    LANGUAGE "sql" STABLE SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
  select exists (
    select 1 from public.memberships
    where org_id = _org and user_id = _uid
  );
$$;


ALTER FUNCTION "public"."is_org_member"("_org" "uuid", "_uid" "uuid") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."pgrst_reload"() RETURNS "void"
    LANGUAGE "sql" SECURITY DEFINER
    AS $$ SELECT pg_notify('pgrst','reload schema'); $$;


ALTER FUNCTION "public"."pgrst_reload"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."publish_valuation_weights"("p_org_id" "uuid", "p_market_key" "text", "p_home_band" "text", "p_weights" "jsonb", "p_note" "text" DEFAULT NULL::"text", "p_effective_at" timestamp with time zone DEFAULT "now"()) RETURNS integer
    LANGUAGE "plpgsql"
    AS $$
declare
  v_next int;
begin
  perform pg_advisory_xact_lock(
    hashtextextended(p_org_id::text || '|' || p_market_key || '|' || p_home_band, 0)
  );

  select coalesce(max(version), 0) + 1
    into v_next
    from public.valuation_weights
   where org_id = p_org_id
     and market_key = p_market_key
     and home_band = p_home_band;

  insert into public.valuation_weights (org_id, market_key, home_band, strategy, weight, version, effective_at, note)
  select p_org_id,
         p_market_key,
         p_home_band,
         w.key,
         (w.value)::numeric,
         v_next,
         p_effective_at,
         p_note
    from jsonb_each_text(p_weights) as w(key, value);

  return v_next;
end;
$$;


ALTER FUNCTION "public"."publish_valuation_weights"("p_org_id" "uuid", "p_market_key" "text", "p_home_band" "text", "p_weights" "jsonb", "p_note" "text", "p_effective_at" timestamp with time zone) OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."runs_bi_fill"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if new.input_hash  is null then
    new.input_hash  := encode(digest(coalesce(new.input::text,  'null'), 'sha256'), 'hex');
  end if;
  if new.output_hash is null then
    new.output_hash := encode(digest(coalesce(new.output::text, 'null'), 'sha256'), 'hex');
  end if;

  -- derive policy_hash from the referenced policy snapshot if present
  if new.policy_hash is null and new.policy_version_id is not null then
    select encode(digest(coalesce(pv.policy_json::text,'null'),'sha256'),'hex')
      into new.policy_hash
    from public.policy_versions pv
    where pv.id = new.policy_version_id;
  end if;

  if new.created_by is null then
    new.created_by := auth.uid();  -- supabase PostgREST injects the auth role here
  end if;
  if new.created_at is null then
    new.created_at := now();
  end if;

  return new;
end
$$;


ALTER FUNCTION "public"."runs_bi_fill"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."set_created_by"() RETURNS "trigger"
    LANGUAGE "plpgsql" SECURITY DEFINER
    SET "search_path" TO 'public'
    AS $$
begin
  if new.created_by is null then
    new.created_by := auth.uid();
  end if;
  return new;
end $$;


ALTER FUNCTION "public"."set_created_by"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."sha256_hex_jsonb"("j" "jsonb") RETURNS "text"
    LANGUAGE "sql" STABLE
    AS $$
  select encode(digest(coalesce(j::text, 'null'), 'sha256'), 'hex')
$$;


ALTER FUNCTION "public"."sha256_hex_jsonb"("j" "jsonb") OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_ai_chat_messages_fill"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
declare
  v_thread record;
begin
  select user_id, org_id, persona into v_thread
  from public.ai_chat_threads
  where id = new.thread_id;

  if not found then
    raise exception 'ai_chat_messages thread_id % not found', new.thread_id;
  end if;

  new.user_id := v_thread.user_id;
  new.org_id := v_thread.org_id;
  new.persona := v_thread.persona;
  return new;
end
$$;


ALTER FUNCTION "public"."tg_ai_chat_messages_fill"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_ai_chat_threads_bump"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  update public.ai_chat_threads
     set updated_at = now(),
         last_message_at = coalesce(new.created_at, now()),
         expires_at = greatest(expires_at, now() + interval '30 days')
   where id = new.thread_id;
  return null;
end
$$;


ALTER FUNCTION "public"."tg_ai_chat_threads_bump"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_deal_contracts_immutable"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  if new.created_by is distinct from old.created_by then
    raise exception 'deal_contracts.created_by is immutable';
  end if;
  if new.org_id is distinct from old.org_id then
    raise exception 'deal_contracts.org_id is immutable';
  end if;
  if new.deal_id is distinct from old.deal_id then
    raise exception 'deal_contracts.deal_id is immutable';
  end if;
  if new.created_at is distinct from old.created_at then
    raise exception 'deal_contracts.created_at is immutable';
  end if;
  return new;
end;
$$;


ALTER FUNCTION "public"."tg_deal_contracts_immutable"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_deal_task_states_set_updated_by"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  new.updated_by = auth.uid();
  return new;
end;
$$;


ALTER FUNCTION "public"."tg_deal_task_states_set_updated_by"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  new.metadata =
    jsonb_set(
      coalesce(new.metadata, '{}'::jsonb),
      '{overrides_snapshot}',
      coalesce(
        (
          select jsonb_agg(
            jsonb_build_object(
              'task_key', s.task_key,
              'override_status', s.override_status,
              'note', s.note,
              'expected_by', s.expected_by,
              'created_at', s.created_at,
              'updated_at', s.updated_at
            )
            order by s.task_key
          )
          from public.deal_task_states s
          where s.deal_id = new.deal_id
            and s.org_id = new.org_id
        ),
        '[]'::jsonb
      ),
      true
    );

  return new;
end;
$$;


ALTER FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"() OWNER TO "postgres";


CREATE OR REPLACE FUNCTION "public"."tg_set_updated_at"() RETURNS "trigger"
    LANGUAGE "plpgsql"
    AS $$
begin
  new.updated_at := now();
  return new;
end
$$;


ALTER FUNCTION "public"."tg_set_updated_at"() OWNER TO "postgres";

SET default_tablespace = '';

SET default_table_access_method = "heap";


CREATE TABLE IF NOT EXISTS "public"."organizations" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "name" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."organizations" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."_default_org" AS
 SELECT "id" AS "org_id"
   FROM "public"."organizations"
  WHERE ("name" = 'HPS DealEngine'::"text")
 LIMIT 1;


ALTER VIEW "public"."_default_org" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."agent_runs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "persona" "text" NOT NULL,
    "agent_name" "text" NOT NULL,
    "workflow_version" "text" NOT NULL,
    "deal_id" "uuid",
    "run_id" "uuid",
    "thread_id" "uuid",
    "trace_id" "text",
    "model" "text",
    "status" "text" DEFAULT 'succeeded'::"text" NOT NULL,
    "input" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "output" "jsonb",
    "error" "jsonb",
    "latency_ms" integer,
    "total_tokens" integer,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "agent_runs_persona_check" CHECK (("persona" = ANY (ARRAY['dealAnalyst'::"text", 'dealStrategist'::"text", 'dealNegotiator'::"text"])))
);


ALTER TABLE "public"."agent_runs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ai_chat_messages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "thread_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "org_id" "uuid" NOT NULL,
    "persona" "text" NOT NULL,
    "role" "text" NOT NULL,
    "content" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ai_chat_messages_persona_check" CHECK (("persona" = ANY (ARRAY['dealAnalyst'::"text", 'dealStrategist'::"text", 'dealNegotiator'::"text"]))),
    CONSTRAINT "ai_chat_messages_role_check" CHECK (("role" = ANY (ARRAY['user'::"text", 'assistant'::"text", 'system'::"text"])))
);


ALTER TABLE "public"."ai_chat_messages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."ai_chat_threads" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "org_id" "uuid" NOT NULL,
    "persona" "text" NOT NULL,
    "title" "text",
    "tone" "text",
    "deal_id" "uuid",
    "run_id" "uuid",
    "posture" "text",
    "last_message_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone DEFAULT ("now"() + '30 days'::interval) NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "ai_chat_threads_persona_check" CHECK (("persona" = ANY (ARRAY['dealAnalyst'::"text", 'dealStrategist'::"text", 'dealNegotiator'::"text"])))
);


ALTER TABLE "public"."ai_chat_threads" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."audit_logs" (
    "id" bigint NOT NULL,
    "org_id" "uuid" NOT NULL,
    "actor_user_id" "uuid",
    "action" "text" NOT NULL,
    "entity" "text" NOT NULL,
    "entity_id" "uuid",
    "details" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "table_name" "text",
    "row_id_uuid" "uuid",
    "diff" "jsonb"
);


ALTER TABLE "public"."audit_logs" OWNER TO "postgres";


COMMENT ON TABLE "public"."audit_logs" IS 'Coarse audit via triggers; SELECT scoped by org membership.';



CREATE SEQUENCE IF NOT EXISTS "public"."audit_logs_id_seq"
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE "public"."audit_logs_id_seq" OWNER TO "postgres";


ALTER SEQUENCE "public"."audit_logs_id_seq" OWNED BY "public"."audit_logs"."id";



CREATE TABLE IF NOT EXISTS "public"."deal_contracts" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "status" "text" DEFAULT 'under_contract'::"text" NOT NULL,
    "executed_contract_price" numeric,
    "executed_contract_date" "date",
    "notes" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "deal_contracts_status_check" CHECK (("status" = ANY (ARRAY['under_contract'::"text", 'closed'::"text", 'cancelled'::"text"]))),
    CONSTRAINT "deal_contracts_under_contract_price_check" CHECK ((("status" <> 'under_contract'::"text") OR ("executed_contract_price" IS NOT NULL)))
);


ALTER TABLE "public"."deal_contracts" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."deal_task_states" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "task_key" "text" NOT NULL,
    "override_status" "text" NOT NULL,
    "note" "text",
    "expected_by" timestamp with time zone,
    "schema_version" integer DEFAULT 1 NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    CONSTRAINT "deal_task_states_note_len" CHECK ((("note" IS NULL) OR ("char_length"("note") <= 1000))),
    CONSTRAINT "deal_task_states_override_status_check" CHECK (("override_status" = ANY (ARRAY['NOT_APPLICABLE'::"text", 'NOT_YET_AVAILABLE'::"text"]))),
    CONSTRAINT "deal_task_states_task_key_nonempty" CHECK (("char_length"("task_key") > 0))
);


ALTER TABLE "public"."deal_task_states" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."deal_workflow_events" (
    "id" "uuid" NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "event_type" "public"."deal_workflow_event_type" NOT NULL,
    "run_id" "uuid" NOT NULL,
    "policy_hash" "text" NOT NULL,
    "event_hash" "text" NOT NULL,
    "metadata" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "deal_workflow_events_event_hash_len" CHECK (("char_length"("event_hash") = 64)),
    CONSTRAINT "deal_workflow_events_policy_hash_nonempty" CHECK (("char_length"("policy_hash") > 0))
);


ALTER TABLE "public"."deal_workflow_events" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."deal_working_states" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "posture" "text" DEFAULT 'base'::"text" NOT NULL,
    "payload" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "source_run_id" "uuid",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "deal_working_states_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);


ALTER TABLE "public"."deal_working_states" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."deals" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "address" "text",
    "city" "text",
    "state" "text",
    "zip" "text",
    "payload" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "client_name" "text",
    "client_phone" "text",
    "client_email" "text"
);


ALTER TABLE "public"."deals" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."evidence" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "run_id" "uuid",
    "kind" "text" NOT NULL,
    "storage_key" "text" NOT NULL,
    "sha256" "text" NOT NULL,
    "bytes" bigint NOT NULL,
    "mime_type" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"(),
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "filename" "text",
    "updated_at" timestamp with time zone
);


ALTER TABLE "public"."evidence" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."market_price_index" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "source" "text" NOT NULL,
    "provider" "text" NOT NULL,
    "series_id" "text" NOT NULL,
    "geo_key" "text" NOT NULL,
    "period" "text" NOT NULL,
    "index_value" numeric NOT NULL,
    "as_of" timestamp with time zone DEFAULT "now"() NOT NULL,
    "raw" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."market_price_index" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."memberships" (
    "org_id" "uuid" NOT NULL,
    "user_id" "uuid" NOT NULL,
    "role" "public"."membership_role" DEFAULT 'analyst'::"public"."membership_role" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."memberships" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."offer_packages" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "run_id" "uuid" NOT NULL,
    "template_version" "text" DEFAULT 'v1'::"text" NOT NULL,
    "policy_snapshot" "jsonb" NOT NULL,
    "arv_source" "text",
    "arv_as_of" "text",
    "arv_valuation_run_id" "uuid",
    "as_is_value_source" "text",
    "as_is_value_as_of" "text",
    "as_is_value_valuation_run_id" "uuid",
    "payload" "jsonb" NOT NULL,
    "payload_hash" "text" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."offer_packages" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."policies" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "posture" "text" DEFAULT 'base'::"text" NOT NULL,
    "tokens" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "metadata" "jsonb",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "policy_json" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "is_active" boolean DEFAULT false NOT NULL,
    CONSTRAINT "policies_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);

ALTER TABLE ONLY "public"."policies" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."policies" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."policy_overrides" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "run_id" "uuid",
    "posture" "text" NOT NULL,
    "token_key" "text" NOT NULL,
    "requested_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "requested_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "approved_by" "uuid",
    "approved_at" timestamp with time zone,
    "status" "public"."policy_override_status" DEFAULT 'pending'::"public"."policy_override_status",
    "justification" "text" DEFAULT ''::"text" NOT NULL,
    "new_value" "jsonb" NOT NULL,
    "policy_version_id" "uuid",
    "deal_id" "uuid",
    "old_value" "jsonb"
);


ALTER TABLE "public"."policy_overrides" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."policy_versions" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "posture" "text" NOT NULL,
    "policy_json" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "change_summary" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" NOT NULL,
    CONSTRAINT "policy_versions_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);

ALTER TABLE ONLY "public"."policy_versions" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."policy_versions" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."policy_versions_api" AS
 SELECT "id" AS "version_id",
    "org_id",
    "posture",
    "created_by" AS "actor_user_id",
    "created_at",
    "change_summary"
   FROM "public"."policy_versions" "pv";


ALTER VIEW "public"."policy_versions_api" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."property_snapshots" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "address_fingerprint" "text" NOT NULL,
    "source" "text" NOT NULL,
    "provider" "text",
    "as_of" timestamp with time zone DEFAULT "now"() NOT NULL,
    "window_days" integer,
    "sample_n" integer,
    "comps" "jsonb",
    "market" "jsonb",
    "raw" "jsonb",
    "stub" boolean DEFAULT false NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "expires_at" timestamp with time zone
);


ALTER TABLE "public"."property_snapshots" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."repair_rate_sets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "market_code" "text" NOT NULL,
    "as_of" "date" NOT NULL,
    "source" "text",
    "version" "text" NOT NULL,
    "is_active" boolean DEFAULT true NOT NULL,
    "repair_psf_tiers" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "repair_big5" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "line_item_rates" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "name" "text" DEFAULT 'Default'::"text" NOT NULL,
    "posture" "text" DEFAULT 'base'::"text" NOT NULL,
    "is_default" boolean DEFAULT false NOT NULL,
    CONSTRAINT "repair_rate_sets_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);


ALTER TABLE "public"."repair_rate_sets" OWNER TO "postgres";


COMMENT ON TABLE "public"."repair_rate_sets" IS 'Versioned repair rate sets (PSF tiers, Big 5, line item rates) scoped by org/market.';



CREATE TABLE IF NOT EXISTS "public"."runs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "posture" "public"."policy_posture" NOT NULL,
    "policy_version_id" "uuid",
    "input" "jsonb" NOT NULL,
    "output" "jsonb" NOT NULL,
    "trace" "jsonb" NOT NULL,
    "input_hash" "text" NOT NULL,
    "output_hash" "text" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "timezone"('utc'::"text", "now"()) NOT NULL,
    "policy_hash" "text",
    "policy_snapshot" "jsonb" DEFAULT '{}'::"jsonb",
    "deal_id" "uuid"
);

ALTER TABLE ONLY "public"."runs" FORCE ROW LEVEL SECURITY;


ALTER TABLE "public"."runs" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."runs_api" AS
 SELECT "id",
    "org_id",
    "created_by",
    "posture",
    "policy_version_id",
    "created_at",
    "input_hash",
    "output_hash"
   FROM "public"."runs";


ALTER VIEW "public"."runs_api" OWNER TO "postgres";


CREATE OR REPLACE VIEW "public"."runs_latest_per_fingerprint" AS
 SELECT "r"."id",
    "r"."org_id",
    "r"."created_by",
    "r"."posture",
    "r"."policy_version_id",
    "r"."input",
    "r"."output",
    "r"."trace",
    "r"."input_hash",
    "r"."output_hash",
    "r"."created_at",
    "r"."policy_hash",
    "r"."policy_snapshot"
   FROM ("public"."runs" "r"
     JOIN ( SELECT "runs"."org_id",
            "runs"."posture",
            "runs"."input_hash",
            "runs"."policy_hash",
            "max"("runs"."created_at") AS "max_created_at"
           FROM "public"."runs"
          GROUP BY "runs"."org_id", "runs"."posture", "runs"."input_hash", "runs"."policy_hash") "latest" ON ((("r"."org_id" = "latest"."org_id") AND ("r"."posture" = "latest"."posture") AND ("r"."input_hash" = "latest"."input_hash") AND (COALESCE("r"."policy_hash", '∅'::"text") = COALESCE("latest"."policy_hash", '∅'::"text")) AND ("r"."created_at" = "latest"."max_created_at"))));


ALTER VIEW "public"."runs_latest_per_fingerprint" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sandbox_presets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "name" "text" NOT NULL,
    "posture" "text" NOT NULL,
    "settings" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "sandbox_presets_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);


ALTER TABLE "public"."sandbox_presets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."sandbox_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "posture" "text" NOT NULL,
    "config" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "sandbox_settings_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"])))
);


ALTER TABLE "public"."sandbox_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."user_settings" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "user_id" "uuid" NOT NULL,
    "org_id" "uuid" NOT NULL,
    "default_posture" "text" DEFAULT 'base'::"text" NOT NULL,
    "default_market" "text" DEFAULT 'ORL'::"text" NOT NULL,
    "theme" "text" DEFAULT 'system'::"text" NOT NULL,
    "ui_prefs" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "user_settings_default_posture_check" CHECK (("default_posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"]))),
    CONSTRAINT "user_settings_theme_check" CHECK (("theme" = ANY (ARRAY['system'::"text", 'dark'::"text", 'light'::"text", 'navy'::"text", 'burgundy'::"text", 'green'::"text", 'black'::"text", 'white'::"text"])))
);


ALTER TABLE "public"."user_settings" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_calibration_buckets" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "market_key" "text" NOT NULL,
    "home_band" "text" NOT NULL,
    "strategy" "text" NOT NULL,
    "n" integer DEFAULT 0 NOT NULL,
    "mae" numeric,
    "mape" numeric,
    "mae_norm" numeric,
    "median_arv" numeric,
    "score_ema" numeric,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    CONSTRAINT "valuation_calibration_buckets_mae_check" CHECK ((("mae" IS NULL) OR ("mae" >= (0)::numeric))),
    CONSTRAINT "valuation_calibration_buckets_mae_norm_check" CHECK ((("mae_norm" IS NULL) OR ("mae_norm" >= (0)::numeric))),
    CONSTRAINT "valuation_calibration_buckets_mape_check" CHECK ((("mape" IS NULL) OR ("mape" >= (0)::numeric))),
    CONSTRAINT "valuation_calibration_buckets_median_arv_check" CHECK ((("median_arv" IS NULL) OR ("median_arv" >= (0)::numeric))),
    CONSTRAINT "valuation_calibration_buckets_n_check" CHECK (("n" >= 0)),
    CONSTRAINT "valuation_calibration_buckets_score_ema_check" CHECK ((("score_ema" IS NULL) OR ("score_ema" >= (0)::numeric)))
);


ALTER TABLE "public"."valuation_calibration_buckets" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_calibration_freezes" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "market_key" "text" NOT NULL,
    "is_frozen" boolean DEFAULT true NOT NULL,
    "reason" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"()
);


ALTER TABLE "public"."valuation_calibration_freezes" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_comp_overrides" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "comp_id" "text" NOT NULL,
    "comp_kind" "text" NOT NULL,
    "seller_credit_pct" numeric,
    "seller_credit_usd" numeric,
    "condition_adjustment_usd" numeric,
    "notes" "text" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "valuation_comp_overrides_comp_kind_check" CHECK (("comp_kind" = ANY (ARRAY['closed_sale'::"text", 'sale_listing'::"text"]))),
    CONSTRAINT "valuation_comp_overrides_seller_credit_pct_check" CHECK ((("seller_credit_pct" IS NULL) OR (("seller_credit_pct" >= (0)::numeric) AND ("seller_credit_pct" <= 0.5))))
);


ALTER TABLE "public"."valuation_comp_overrides" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_eval_runs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "dataset_name" "text" NOT NULL,
    "posture" "text",
    "policy_version_id" "uuid",
    "policy_hash" "text",
    "as_of" timestamp with time zone DEFAULT "now"() NOT NULL,
    "params" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "metrics" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "output_hash" "text",
    "input_hash" "text"
);


ALTER TABLE "public"."valuation_eval_runs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_ground_truth" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid",
    "subject_key" "text" NOT NULL,
    "source" "text" NOT NULL,
    "realized_price" numeric NOT NULL,
    "realized_date" "date",
    "as_of" timestamp with time zone DEFAULT "now"() NOT NULL,
    "notes" "text",
    "raw" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "updated_at" timestamp with time zone DEFAULT "now"() NOT NULL
);


ALTER TABLE "public"."valuation_ground_truth" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_runs" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "posture" "text" NOT NULL,
    "address_fingerprint" "text" NOT NULL,
    "property_snapshot_id" "uuid",
    "input" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "output" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "provenance" "jsonb" DEFAULT '{}'::"jsonb" NOT NULL,
    "status" "text" NOT NULL,
    "failure_reason" "text",
    "input_hash" "text" NOT NULL,
    "output_hash" "text" NOT NULL,
    "policy_hash" "text",
    "run_hash" "text",
    "created_by" "uuid" DEFAULT "auth"."uid"() NOT NULL,
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    CONSTRAINT "valuation_runs_posture_check" CHECK (("posture" = ANY (ARRAY['conservative'::"text", 'base'::"text", 'aggressive'::"text"]))),
    CONSTRAINT "valuation_runs_status_check" CHECK (("status" = ANY (ARRAY['queued'::"text", 'running'::"text", 'succeeded'::"text", 'failed'::"text"])))
);


ALTER TABLE "public"."valuation_runs" OWNER TO "postgres";


CREATE TABLE IF NOT EXISTS "public"."valuation_weights" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "market_key" "text" NOT NULL,
    "home_band" "text" NOT NULL,
    "strategy" "text" NOT NULL,
    "weight" numeric NOT NULL,
    "version" integer NOT NULL,
    "effective_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "note" "text",
    "created_at" timestamp with time zone DEFAULT "now"() NOT NULL,
    "created_by" "uuid" DEFAULT "auth"."uid"(),
    CONSTRAINT "valuation_weights_version_check" CHECK (("version" > 0)),
    CONSTRAINT "valuation_weights_weight_check" CHECK ((("weight" >= (0)::numeric) AND ("weight" <= (1)::numeric)))
);


ALTER TABLE "public"."valuation_weights" OWNER TO "postgres";


ALTER TABLE ONLY "public"."audit_logs" ALTER COLUMN "id" SET DEFAULT "nextval"('"public"."audit_logs_id_seq"'::"regclass");



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ai_chat_messages"
    ADD CONSTRAINT "ai_chat_messages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."ai_chat_threads"
    ADD CONSTRAINT "ai_chat_threads_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."audit_logs"
    ADD CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."deal_contracts"
    ADD CONSTRAINT "deal_contracts_org_id_deal_id_key" UNIQUE ("org_id", "deal_id");



ALTER TABLE ONLY "public"."deal_contracts"
    ADD CONSTRAINT "deal_contracts_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."deal_task_states"
    ADD CONSTRAINT "deal_task_states_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."deal_workflow_events"
    ADD CONSTRAINT "deal_workflow_events_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."deal_working_states"
    ADD CONSTRAINT "deal_working_states_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."deal_working_states"
    ADD CONSTRAINT "deal_working_states_unique_org_user_deal" UNIQUE ("org_id", "user_id", "deal_id");



ALTER TABLE ONLY "public"."deals"
    ADD CONSTRAINT "deals_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."evidence"
    ADD CONSTRAINT "evidence_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."market_price_index"
    ADD CONSTRAINT "market_price_index_org_id_source_provider_series_id_geo_key_key" UNIQUE ("org_id", "source", "provider", "series_id", "geo_key", "period");



ALTER TABLE ONLY "public"."market_price_index"
    ADD CONSTRAINT "market_price_index_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."memberships"
    ADD CONSTRAINT "memberships_pkey" PRIMARY KEY ("org_id", "user_id");



ALTER TABLE ONLY "public"."offer_packages"
    ADD CONSTRAINT "offer_packages_org_id_run_id_template_version_key" UNIQUE ("org_id", "run_id", "template_version");



ALTER TABLE ONLY "public"."offer_packages"
    ADD CONSTRAINT "offer_packages_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."organizations"
    ADD CONSTRAINT "organizations_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."policies"
    ADD CONSTRAINT "policies_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."policy_overrides"
    ADD CONSTRAINT "policy_overrides_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."policy_versions"
    ADD CONSTRAINT "policy_versions_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."property_snapshots"
    ADD CONSTRAINT "property_snapshots_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."repair_rate_sets"
    ADD CONSTRAINT "repair_rate_sets_pkey" PRIMARY KEY ("id");



ALTER TABLE "public"."runs"
    ADD CONSTRAINT "runs_deal_id_not_null" CHECK (("deal_id" IS NOT NULL)) NOT VALID;



ALTER TABLE ONLY "public"."runs"
    ADD CONSTRAINT "runs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."sandbox_presets"
    ADD CONSTRAINT "sandbox_presets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."sandbox_presets"
    ADD CONSTRAINT "sandbox_presets_unique_org_name_posture" UNIQUE ("org_id", "name", "posture");



ALTER TABLE ONLY "public"."sandbox_settings"
    ADD CONSTRAINT "sandbox_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."sandbox_settings"
    ADD CONSTRAINT "sandbox_settings_unique_org_posture" UNIQUE ("org_id", "posture");



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_unique_user_org" UNIQUE ("user_id", "org_id");



ALTER TABLE ONLY "public"."valuation_calibration_buckets"
    ADD CONSTRAINT "valuation_calibration_buckets_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_calibration_freezes"
    ADD CONSTRAINT "valuation_calibration_freezes_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_comp_overrides"
    ADD CONSTRAINT "valuation_comp_overrides_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_comp_overrides"
    ADD CONSTRAINT "valuation_comp_overrides_unique" UNIQUE ("org_id", "deal_id", "comp_id", "comp_kind");



ALTER TABLE ONLY "public"."valuation_eval_runs"
    ADD CONSTRAINT "valuation_eval_runs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_ground_truth"
    ADD CONSTRAINT "valuation_ground_truth_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_runs"
    ADD CONSTRAINT "valuation_runs_pkey" PRIMARY KEY ("id");



ALTER TABLE ONLY "public"."valuation_weights"
    ADD CONSTRAINT "valuation_weights_pkey" PRIMARY KEY ("id");



CREATE INDEX "agent_runs_deal_created_desc" ON "public"."agent_runs" USING "btree" ("deal_id", "created_at" DESC);



CREATE INDEX "agent_runs_org_persona_created_desc" ON "public"."agent_runs" USING "btree" ("org_id", "persona", "created_at" DESC);



CREATE INDEX "agent_runs_run_created_desc" ON "public"."agent_runs" USING "btree" ("run_id", "created_at" DESC);



CREATE INDEX "agent_runs_user_persona_created_desc" ON "public"."agent_runs" USING "btree" ("user_id", "persona", "created_at" DESC);



CREATE INDEX "audit_org_created_idx" ON "public"."audit_logs" USING "btree" ("org_id", "created_at" DESC);



CREATE INDEX "deal_contracts_deal_id_idx" ON "public"."deal_contracts" USING "btree" ("deal_id");



CREATE INDEX "deal_task_states_deal_id_idx" ON "public"."deal_task_states" USING "btree" ("deal_id");



CREATE UNIQUE INDEX "deal_task_states_org_deal_task_uq" ON "public"."deal_task_states" USING "btree" ("org_id", "deal_id", "task_key");



CREATE INDEX "deal_workflow_events_deal_id_idx" ON "public"."deal_workflow_events" USING "btree" ("deal_id");



CREATE UNIQUE INDEX "deal_workflow_events_event_hash_uq" ON "public"."deal_workflow_events" USING "btree" ("event_hash");



CREATE INDEX "idx_ai_chat_messages_org" ON "public"."ai_chat_messages" USING "btree" ("org_id", "persona", "created_at");



CREATE INDEX "idx_ai_chat_messages_thread" ON "public"."ai_chat_messages" USING "btree" ("thread_id", "created_at");



CREATE INDEX "idx_ai_chat_messages_user_persona" ON "public"."ai_chat_messages" USING "btree" ("user_id", "persona", "created_at");



CREATE INDEX "idx_ai_chat_threads_expires" ON "public"."ai_chat_threads" USING "btree" ("expires_at");



CREATE INDEX "idx_ai_chat_threads_org" ON "public"."ai_chat_threads" USING "btree" ("org_id", "persona");



CREATE UNIQUE INDEX "idx_ai_chat_threads_persona_deal_unique" ON "public"."ai_chat_threads" USING "btree" ("org_id", "user_id", "persona", "deal_id") WHERE ("deal_id" IS NOT NULL);



CREATE INDEX "idx_ai_chat_threads_user_persona" ON "public"."ai_chat_threads" USING "btree" ("user_id", "persona", "last_message_at" DESC);



CREATE INDEX "idx_deal_working_states_deal" ON "public"."deal_working_states" USING "btree" ("deal_id", "updated_at" DESC);



CREATE INDEX "idx_deal_working_states_org_user" ON "public"."deal_working_states" USING "btree" ("org_id", "user_id");



CREATE INDEX "idx_deal_working_states_source_run" ON "public"."deal_working_states" USING "btree" ("source_run_id");



CREATE INDEX "idx_evidence_org_deal" ON "public"."evidence" USING "btree" ("org_id", "deal_id");



CREATE INDEX "idx_evidence_run" ON "public"."evidence" USING "btree" ("run_id");



CREATE INDEX "idx_memberships_user_org" ON "public"."memberships" USING "btree" ("user_id", "org_id");



CREATE INDEX "idx_policy_versions_org" ON "public"."policy_versions" USING "btree" ("org_id");



CREATE INDEX "idx_property_snapshots_org_addr_source" ON "public"."property_snapshots" USING "btree" ("org_id", "address_fingerprint", "source", "created_at" DESC);



CREATE INDEX "idx_property_snapshots_org_created_at" ON "public"."property_snapshots" USING "btree" ("org_id", "created_at" DESC);



CREATE INDEX "idx_user_settings_user_org" ON "public"."user_settings" USING "btree" ("user_id", "org_id");



CREATE INDEX "idx_valuation_comp_overrides_org_deal" ON "public"."valuation_comp_overrides" USING "btree" ("org_id", "deal_id");



CREATE INDEX "idx_valuation_comp_overrides_org_deal_kind" ON "public"."valuation_comp_overrides" USING "btree" ("org_id", "deal_id", "comp_kind");



CREATE INDEX "idx_valuation_eval_runs_dataset" ON "public"."valuation_eval_runs" USING "btree" ("dataset_name", "created_at" DESC);



CREATE INDEX "idx_valuation_eval_runs_org_created_at" ON "public"."valuation_eval_runs" USING "btree" ("org_id", "created_at" DESC);



CREATE UNIQUE INDEX "idx_valuation_eval_runs_org_input_hash" ON "public"."valuation_eval_runs" USING "btree" ("org_id", "input_hash") WHERE ("input_hash" IS NOT NULL);



CREATE UNIQUE INDEX "idx_valuation_ground_truth_org_subject_source_date" ON "public"."valuation_ground_truth" USING "btree" ("org_id", "subject_key", "source", COALESCE("realized_date", '0001-01-01'::"date"));



CREATE UNIQUE INDEX "idx_valuation_runs_dedupe" ON "public"."valuation_runs" USING "btree" ("org_id", "deal_id", "posture", "input_hash", COALESCE("policy_hash", ''::"text"));



CREATE INDEX "idx_valuation_runs_org_addr" ON "public"."valuation_runs" USING "btree" ("org_id", "address_fingerprint", "created_at" DESC);



CREATE INDEX "idx_valuation_runs_org_deal_created_at" ON "public"."valuation_runs" USING "btree" ("org_id", "deal_id", "created_at" DESC);



CREATE INDEX "memberships_org_id_idx" ON "public"."memberships" USING "btree" ("org_id");



CREATE INDEX "memberships_user_id_idx" ON "public"."memberships" USING "btree" ("user_id");



CREATE INDEX "offer_packages_deal_created_desc" ON "public"."offer_packages" USING "btree" ("deal_id", "created_at" DESC);



CREATE INDEX "offer_packages_org_created_desc" ON "public"."offer_packages" USING "btree" ("org_id", "created_at" DESC);



CREATE UNIQUE INDEX "policies_one_active_per_posture" ON "public"."policies" USING "btree" ("org_id", "posture") WHERE ("is_active" = true);



CREATE INDEX "policies_org_posture_created_at_idx" ON "public"."policies" USING "btree" ("org_id", "posture", "created_at" DESC);



CREATE UNIQUE INDEX "policies_uni_org_posture_active" ON "public"."policies" USING "btree" ("org_id", "posture") WHERE ("is_active" = true);



CREATE INDEX "policy_overrides_deal_idx" ON "public"."policy_overrides" USING "btree" ("deal_id", "posture");



CREATE INDEX "policy_overrides_org_status_idx" ON "public"."policy_overrides" USING "btree" ("org_id", "status", "requested_at" DESC);



CREATE INDEX "policy_versions_org_posture_created_at_idx" ON "public"."policy_versions" USING "btree" ("org_id", "posture", "created_at" DESC);



CREATE INDEX "repair_rate_sets_org_id_idx" ON "public"."repair_rate_sets" USING "btree" ("org_id");



CREATE UNIQUE INDEX "repair_rate_sets_org_market_posture_active_uidx" ON "public"."repair_rate_sets" USING "btree" ("org_id", "market_code", "posture") WHERE "is_active";



CREATE UNIQUE INDEX "repair_rate_sets_org_market_posture_default_uidx" ON "public"."repair_rate_sets" USING "btree" ("org_id", "market_code", "posture") WHERE "is_default";



CREATE INDEX "runs_creator_idx" ON "public"."runs" USING "btree" ("created_by");



CREATE INDEX "runs_org_created_idx" ON "public"."runs" USING "btree" ("org_id", "created_at" DESC);



CREATE INDEX "runs_org_deal_created_idx" ON "public"."runs" USING "btree" ("org_id", "deal_id", "created_at" DESC);



CREATE UNIQUE INDEX "runs_uni_org_posture_hashes" ON "public"."runs" USING "btree" ("org_id", "posture", "input_hash", "policy_hash");



CREATE UNIQUE INDEX "runs_uni_org_posture_iohash_polhash" ON "public"."runs" USING "btree" ("org_id", "posture", "input_hash", "policy_hash");



CREATE INDEX "valuation_calibration_buckets_bucket_idx" ON "public"."valuation_calibration_buckets" USING "btree" ("org_id", "market_key", "home_band");



CREATE INDEX "valuation_calibration_buckets_strategy_idx" ON "public"."valuation_calibration_buckets" USING "btree" ("org_id", "strategy");



CREATE UNIQUE INDEX "valuation_calibration_buckets_uq" ON "public"."valuation_calibration_buckets" USING "btree" ("org_id", "market_key", "home_band", "strategy");



CREATE INDEX "valuation_calibration_freezes_org_market_idx" ON "public"."valuation_calibration_freezes" USING "btree" ("org_id", "market_key");



CREATE UNIQUE INDEX "valuation_calibration_freezes_uq" ON "public"."valuation_calibration_freezes" USING "btree" ("org_id", "market_key");



CREATE UNIQUE INDEX "valuation_ground_truth_org_subject_source_date_uidx" ON "public"."valuation_ground_truth" USING "btree" ("org_id", "subject_key", "source", "realized_date");



CREATE INDEX "valuation_weights_bucket_latest_idx" ON "public"."valuation_weights" USING "btree" ("org_id", "market_key", "home_band", "version" DESC);



CREATE INDEX "valuation_weights_strategy_idx" ON "public"."valuation_weights" USING "btree" ("org_id", "strategy");



CREATE UNIQUE INDEX "valuation_weights_uq" ON "public"."valuation_weights" USING "btree" ("org_id", "market_key", "home_band", "strategy", "version");



CREATE OR REPLACE TRIGGER "ai_chat_messages_bump_thread" AFTER INSERT ON "public"."ai_chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."tg_ai_chat_threads_bump"();



CREATE OR REPLACE TRIGGER "ai_chat_messages_fill" BEFORE INSERT ON "public"."ai_chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."tg_ai_chat_messages_fill"();



CREATE OR REPLACE TRIGGER "audit_agent_runs" AFTER INSERT OR DELETE OR UPDATE ON "public"."agent_runs" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_ai_chat_messages" AFTER INSERT OR DELETE OR UPDATE ON "public"."ai_chat_messages" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_ai_chat_threads" AFTER INSERT OR DELETE OR UPDATE ON "public"."ai_chat_threads" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_deal_contracts" AFTER INSERT OR DELETE OR UPDATE ON "public"."deal_contracts" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_deal_working_states" AFTER INSERT OR DELETE OR UPDATE ON "public"."deal_working_states" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_deals" AFTER INSERT OR DELETE OR UPDATE ON "public"."deals" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_evidence" AFTER INSERT OR DELETE OR UPDATE ON "public"."evidence" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_offer_packages" AFTER INSERT OR DELETE OR UPDATE ON "public"."offer_packages" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_policies" AFTER INSERT OR DELETE OR UPDATE ON "public"."policies" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_policy_versions" AFTER INSERT OR DELETE OR UPDATE ON "public"."policy_versions" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_property_snapshots" AFTER INSERT OR DELETE OR UPDATE ON "public"."property_snapshots" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_repair_rate_sets" AFTER INSERT OR DELETE OR UPDATE ON "public"."repair_rate_sets" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_runs" AFTER INSERT OR DELETE OR UPDATE ON "public"."runs" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_sandbox_presets" AFTER INSERT OR DELETE OR UPDATE ON "public"."sandbox_presets" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_sandbox_settings" AFTER INSERT OR DELETE OR UPDATE ON "public"."sandbox_settings" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_user_settings" AFTER INSERT OR DELETE OR UPDATE ON "public"."user_settings" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_calibration_buckets" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_calibration_buckets" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_calibration_freezes" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_calibration_freezes" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_comp_overrides" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_comp_overrides" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_eval_runs" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_eval_runs" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_ground_truth" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_ground_truth" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_runs" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_runs" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "audit_valuation_weights" AFTER INSERT OR DELETE OR UPDATE ON "public"."valuation_weights" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "deal_task_states_audit_row_change" AFTER INSERT OR DELETE OR UPDATE ON "public"."deal_task_states" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "deal_task_states_set_updated_at" BEFORE UPDATE ON "public"."deal_task_states" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "deal_task_states_set_updated_by" BEFORE UPDATE ON "public"."deal_task_states" FOR EACH ROW EXECUTE FUNCTION "public"."tg_deal_task_states_set_updated_by"();



CREATE OR REPLACE TRIGGER "deal_workflow_events_audit_row_change" AFTER INSERT ON "public"."deal_workflow_events" FOR EACH ROW EXECUTE FUNCTION "public"."audit_log_row_change"();



CREATE OR REPLACE TRIGGER "deal_workflow_events_snapshot_overrides" BEFORE INSERT ON "public"."deal_workflow_events" FOR EACH ROW EXECUTE FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"();



CREATE OR REPLACE TRIGGER "prevent_deal_contracts_immutable" BEFORE UPDATE ON "public"."deal_contracts" FOR EACH ROW EXECUTE FUNCTION "public"."tg_deal_contracts_immutable"();



CREATE OR REPLACE TRIGGER "set_ai_chat_threads_updated_at" BEFORE UPDATE ON "public"."ai_chat_threads" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_deal_contracts_updated_at" BEFORE UPDATE ON "public"."deal_contracts" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_deal_working_states_updated_at" BEFORE UPDATE ON "public"."deal_working_states" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_deals_updated_at" BEFORE UPDATE ON "public"."deals" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_evidence_updated_at" BEFORE UPDATE ON "public"."evidence" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_offer_packages_updated_at" BEFORE UPDATE ON "public"."offer_packages" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_sandbox_presets_updated_at" BEFORE UPDATE ON "public"."sandbox_presets" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_sandbox_settings_updated_at" BEFORE UPDATE ON "public"."sandbox_settings" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_user_settings_updated_at" BEFORE UPDATE ON "public"."user_settings" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_valuation_calibration_buckets_updated_at" BEFORE UPDATE ON "public"."valuation_calibration_buckets" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_valuation_calibration_freezes_updated_at" BEFORE UPDATE ON "public"."valuation_calibration_freezes" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_valuation_comp_overrides_updated_at" BEFORE UPDATE ON "public"."valuation_comp_overrides" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "set_valuation_ground_truth_updated_at" BEFORE UPDATE ON "public"."valuation_ground_truth" FOR EACH ROW EXECUTE FUNCTION "public"."tg_set_updated_at"();



CREATE OR REPLACE TRIGGER "trg_runs_bi_fill" BEFORE INSERT ON "public"."runs" FOR EACH ROW EXECUTE FUNCTION "public"."runs_bi_fill"();



CREATE OR REPLACE TRIGGER "trg_runs_set_created_by" BEFORE INSERT ON "public"."runs" FOR EACH ROW EXECUTE FUNCTION "public"."set_created_by"();



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_run_id_fkey" FOREIGN KEY ("run_id") REFERENCES "public"."runs"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_thread_id_fkey" FOREIGN KEY ("thread_id") REFERENCES "public"."ai_chat_threads"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."agent_runs"
    ADD CONSTRAINT "agent_runs_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ai_chat_messages"
    ADD CONSTRAINT "ai_chat_messages_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ai_chat_messages"
    ADD CONSTRAINT "ai_chat_messages_thread_id_fkey" FOREIGN KEY ("thread_id") REFERENCES "public"."ai_chat_threads"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."ai_chat_threads"
    ADD CONSTRAINT "ai_chat_threads_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_contracts"
    ADD CONSTRAINT "deal_contracts_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id");



ALTER TABLE ONLY "public"."deal_contracts"
    ADD CONSTRAINT "deal_contracts_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id");



ALTER TABLE ONLY "public"."deal_task_states"
    ADD CONSTRAINT "deal_task_states_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_task_states"
    ADD CONSTRAINT "deal_task_states_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_workflow_events"
    ADD CONSTRAINT "deal_workflow_events_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_workflow_events"
    ADD CONSTRAINT "deal_workflow_events_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_workflow_events"
    ADD CONSTRAINT "deal_workflow_events_run_id_fkey" FOREIGN KEY ("run_id") REFERENCES "public"."runs"("id") ON DELETE RESTRICT;



ALTER TABLE ONLY "public"."deal_working_states"
    ADD CONSTRAINT "deal_working_states_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_working_states"
    ADD CONSTRAINT "deal_working_states_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."deal_working_states"
    ADD CONSTRAINT "deal_working_states_source_run_id_fkey" FOREIGN KEY ("source_run_id") REFERENCES "public"."runs"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."deals"
    ADD CONSTRAINT "deals_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."memberships"
    ADD CONSTRAINT "memberships_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."offer_packages"
    ADD CONSTRAINT "offer_packages_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id");



ALTER TABLE ONLY "public"."offer_packages"
    ADD CONSTRAINT "offer_packages_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id");



ALTER TABLE ONLY "public"."offer_packages"
    ADD CONSTRAINT "offer_packages_run_id_fkey" FOREIGN KEY ("run_id") REFERENCES "public"."runs"("id");



ALTER TABLE ONLY "public"."policy_overrides"
    ADD CONSTRAINT "policy_overrides_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."policy_overrides"
    ADD CONSTRAINT "policy_overrides_policy_version_id_fkey" FOREIGN KEY ("policy_version_id") REFERENCES "public"."policy_versions"("id");



ALTER TABLE ONLY "public"."property_snapshots"
    ADD CONSTRAINT "property_snapshots_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."repair_rate_sets"
    ADD CONSTRAINT "repair_rate_sets_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."runs"
    ADD CONSTRAINT "runs_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."runs"
    ADD CONSTRAINT "runs_policy_version_id_fkey" FOREIGN KEY ("policy_version_id") REFERENCES "public"."policy_versions"("id");



ALTER TABLE ONLY "public"."sandbox_presets"
    ADD CONSTRAINT "sandbox_presets_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."sandbox_settings"
    ADD CONSTRAINT "sandbox_settings_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."user_settings"
    ADD CONSTRAINT "user_settings_user_id_fkey" FOREIGN KEY ("user_id") REFERENCES "auth"."users"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_calibration_buckets"
    ADD CONSTRAINT "valuation_calibration_buckets_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_calibration_freezes"
    ADD CONSTRAINT "valuation_calibration_freezes_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_comp_overrides"
    ADD CONSTRAINT "valuation_comp_overrides_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_comp_overrides"
    ADD CONSTRAINT "valuation_comp_overrides_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_eval_runs"
    ADD CONSTRAINT "valuation_eval_runs_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_eval_runs"
    ADD CONSTRAINT "valuation_eval_runs_policy_version_id_fkey" FOREIGN KEY ("policy_version_id") REFERENCES "public"."policy_versions"("id");



ALTER TABLE ONLY "public"."valuation_ground_truth"
    ADD CONSTRAINT "valuation_ground_truth_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE SET NULL;



ALTER TABLE ONLY "public"."valuation_ground_truth"
    ADD CONSTRAINT "valuation_ground_truth_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_runs"
    ADD CONSTRAINT "valuation_runs_deal_id_fkey" FOREIGN KEY ("deal_id") REFERENCES "public"."deals"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_runs"
    ADD CONSTRAINT "valuation_runs_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



ALTER TABLE ONLY "public"."valuation_runs"
    ADD CONSTRAINT "valuation_runs_property_snapshot_id_fkey" FOREIGN KEY ("property_snapshot_id") REFERENCES "public"."property_snapshots"("id");



ALTER TABLE ONLY "public"."valuation_weights"
    ADD CONSTRAINT "valuation_weights_org_id_fkey" FOREIGN KEY ("org_id") REFERENCES "public"."organizations"("id") ON DELETE CASCADE;



CREATE POLICY "Analysts request overrides" ON "public"."policy_overrides" FOR INSERT WITH CHECK (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE ("memberships"."user_id" = "auth"."uid"()))));



CREATE POLICY "Managers approve overrides" ON "public"."policy_overrides" FOR UPDATE USING (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE (("memberships"."user_id" = "auth"."uid"()) AND ("memberships"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"])))))) WITH CHECK (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE (("memberships"."user_id" = "auth"."uid"()) AND ("memberships"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



CREATE POLICY "Org members view overrides" ON "public"."policy_overrides" FOR SELECT USING (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE ("memberships"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can upload own org evidence" ON "public"."evidence" FOR INSERT WITH CHECK (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE ("memberships"."user_id" = "auth"."uid"()))));



CREATE POLICY "Users can view own org evidence" ON "public"."evidence" FOR SELECT USING (("org_id" IN ( SELECT "memberships"."org_id"
   FROM "public"."memberships"
  WHERE ("memberships"."user_id" = "auth"."uid"()))));



ALTER TABLE "public"."agent_runs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "agent_runs_delete" ON "public"."agent_runs" FOR DELETE USING ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("user_id" = "auth"."uid"())));



CREATE POLICY "agent_runs_insert" ON "public"."agent_runs" FOR INSERT WITH CHECK ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("user_id" = "auth"."uid"())));



CREATE POLICY "agent_runs_select" ON "public"."agent_runs" FOR SELECT USING ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("user_id" = "auth"."uid"())));



CREATE POLICY "agent_runs_update" ON "public"."agent_runs" FOR UPDATE USING ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("user_id" = "auth"."uid"()))) WITH CHECK ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("user_id" = "auth"."uid"())));



ALTER TABLE "public"."ai_chat_messages" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "ai_chat_messages_delete" ON "public"."ai_chat_messages" FOR DELETE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_messages"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_messages_insert" ON "public"."ai_chat_messages" FOR INSERT WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_messages"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_messages_select" ON "public"."ai_chat_messages" FOR SELECT USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_messages"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_messages_update" ON "public"."ai_chat_messages" FOR UPDATE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_messages"."org_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_messages"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."ai_chat_threads" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "ai_chat_threads_delete" ON "public"."ai_chat_threads" FOR DELETE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_threads"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_threads_insert" ON "public"."ai_chat_threads" FOR INSERT WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_threads"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_threads_select" ON "public"."ai_chat_threads" FOR SELECT USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_threads"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "ai_chat_threads_update" ON "public"."ai_chat_threads" FOR UPDATE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_threads"."org_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "ai_chat_threads"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "audit_insert" ON "public"."audit_logs" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "audit_logs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."audit_logs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "audit_logs_select_in_org" ON "public"."audit_logs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "audit_logs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "audit_select" ON "public"."audit_logs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "audit_logs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."deal_contracts" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deal_contracts_insert" ON "public"."deal_contracts" FOR INSERT WITH CHECK ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("created_by" = "auth"."uid"())));



CREATE POLICY "deal_contracts_select" ON "public"."deal_contracts" FOR SELECT USING (("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))));



CREATE POLICY "deal_contracts_update" ON "public"."deal_contracts" FOR UPDATE USING (("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"())))) WITH CHECK (("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))));



ALTER TABLE "public"."deal_task_states" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deal_task_states_delete_members" ON "public"."deal_task_states" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_task_states"."deal_id") AND ("d"."org_id" = "deal_task_states"."org_id")))));



CREATE POLICY "deal_task_states_insert_members" ON "public"."deal_task_states" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_task_states"."deal_id") AND ("d"."org_id" = "deal_task_states"."org_id")))));



CREATE POLICY "deal_task_states_select_members" ON "public"."deal_task_states" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_task_states"."deal_id") AND ("d"."org_id" = "deal_task_states"."org_id")))));



CREATE POLICY "deal_task_states_update_members" ON "public"."deal_task_states" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_task_states"."deal_id") AND ("d"."org_id" = "deal_task_states"."org_id"))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_task_states"."deal_id") AND ("d"."org_id" = "deal_task_states"."org_id")))));



ALTER TABLE "public"."deal_workflow_events" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deal_workflow_events_insert_members" ON "public"."deal_workflow_events" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_workflow_events"."deal_id") AND ("d"."org_id" = "deal_workflow_events"."org_id")))));



CREATE POLICY "deal_workflow_events_select_members" ON "public"."deal_workflow_events" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM ("public"."deals" "d"
     JOIN "public"."memberships" "m" ON ((("m"."org_id" = "d"."org_id") AND ("m"."user_id" = "auth"."uid"()))))
  WHERE (("d"."id" = "deal_workflow_events"."deal_id") AND ("d"."org_id" = "deal_workflow_events"."org_id")))));



ALTER TABLE "public"."deal_working_states" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deal_working_states_delete" ON "public"."deal_working_states" FOR DELETE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deal_working_states"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "deal_working_states_insert" ON "public"."deal_working_states" FOR INSERT WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deal_working_states"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "deal_working_states_select" ON "public"."deal_working_states" FOR SELECT USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deal_working_states"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "deal_working_states_update" ON "public"."deal_working_states" FOR UPDATE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deal_working_states"."org_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deal_working_states"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."deals" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "deals_delete_manager" ON "public"."deals" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deals"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



CREATE POLICY "deals_insert_in_org" ON "public"."deals" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deals"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "deals_select_in_org" ON "public"."deals" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deals"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "deals_update_in_org" ON "public"."deals" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deals"."org_id") AND ("m"."user_id" = "auth"."uid"()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "deals"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."evidence" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "evidence_delete" ON "public"."evidence" FOR DELETE USING ((("created_by" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "evidence"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "evidence_insert" ON "public"."evidence" FOR INSERT WITH CHECK ((("created_by" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "evidence"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "evidence_select" ON "public"."evidence" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "evidence"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "evidence_update" ON "public"."evidence" FOR UPDATE USING ((("created_by" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "evidence"."org_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK ((("created_by" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "evidence"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."market_price_index" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "market_price_index_ins" ON "public"."market_price_index" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "market_price_index"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "market_price_index_sel" ON "public"."market_price_index" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "market_price_index"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "mbr_delete_self" ON "public"."memberships" FOR DELETE TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "mbr_insert_self" ON "public"."memberships" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "mbr_select_self" ON "public"."memberships" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "mbr_self_select" ON "public"."memberships" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "mbr_update_self" ON "public"."memberships" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "membership_delete_self" ON "public"."memberships" FOR DELETE TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "membership_insert_self" ON "public"."memberships" FOR INSERT TO "authenticated" WITH CHECK (("user_id" = "auth"."uid"()));



CREATE POLICY "membership_select_self" ON "public"."memberships" FOR SELECT TO "authenticated" USING (("user_id" = "auth"."uid"()));



CREATE POLICY "membership_update_self" ON "public"."memberships" FOR UPDATE TO "authenticated" USING (("user_id" = "auth"."uid"())) WITH CHECK (("user_id" = "auth"."uid"()));



ALTER TABLE "public"."memberships" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."offer_packages" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "offer_packages_insert" ON "public"."offer_packages" FOR INSERT WITH CHECK ((("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))) AND ("created_by" = "auth"."uid"())));



CREATE POLICY "offer_packages_select" ON "public"."offer_packages" FOR SELECT USING (("org_id" IN ( SELECT "m"."org_id"
   FROM "public"."memberships" "m"
  WHERE ("m"."user_id" = "auth"."uid"()))));



CREATE POLICY "org_select" ON "public"."organizations" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "organizations"."id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."organizations" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "orgs:select_by_membership" ON "public"."organizations" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "organizations"."id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "pol_read_by_membership_simple" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "pol_read_by_org" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "pol_select_by_membership" ON "public"."policies" FOR SELECT TO "authenticated" USING ("public"."is_member_of"("org_id"));



CREATE POLICY "pol_select_org_members" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "pol_select_visible_to_members" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."policies" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "policies_delete" ON "public"."policies" FOR DELETE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = 'vp'::"public"."membership_role")))));



CREATE POLICY "policies_insert" ON "public"."policies" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



CREATE POLICY "policies_select" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "policies_select_by_membership" ON "public"."policies" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "policies_update" ON "public"."policies" FOR UPDATE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policies"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



ALTER TABLE "public"."policy_overrides" ENABLE ROW LEVEL SECURITY;


ALTER TABLE "public"."policy_versions" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "policy_versions_insert" ON "public"."policy_versions" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policy_versions"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



CREATE POLICY "policy_versions_select" ON "public"."policy_versions" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policy_versions"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "policy_versions_select_by_membership" ON "public"."policy_versions" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policy_versions"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "polv_read_by_org" ON "public"."policy_versions" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policy_versions"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "polv_select_by_membership" ON "public"."policy_versions" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "policy_versions"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."property_snapshots" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "property_snapshots_insert_in_org" ON "public"."property_snapshots" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "property_snapshots"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "property_snapshots_select_in_org" ON "public"."property_snapshots" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "property_snapshots"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."repair_rate_sets" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "repair_rate_sets_delete_manager" ON "public"."repair_rate_sets" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "repair_rate_sets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "repair_rate_sets_insert_manager" ON "public"."repair_rate_sets" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "repair_rate_sets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "repair_rate_sets_select_in_org" ON "public"."repair_rate_sets" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "repair_rate_sets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "repair_rate_sets_update_manager" ON "public"."repair_rate_sets" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "repair_rate_sets"."org_id") AND ("m"."user_id" = "auth"."uid"()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "repair_rate_sets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."runs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "runs_insert" ON "public"."runs" FOR INSERT TO "authenticated" WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "runs_select" ON "public"."runs" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "runs_update" ON "public"."runs" FOR UPDATE TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "runs"."org_id") AND ("m"."user_id" = "auth"."uid"()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."sandbox_presets" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "sandbox_presets_delete" ON "public"."sandbox_presets" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_presets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_presets_insert" ON "public"."sandbox_presets" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_presets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_presets_select" ON "public"."sandbox_presets" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_presets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_presets_update" ON "public"."sandbox_presets" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_presets"."org_id") AND ("m"."user_id" = "auth"."uid"()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_presets"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."sandbox_settings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "sandbox_settings_delete" ON "public"."sandbox_settings" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_settings"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_settings_insert" ON "public"."sandbox_settings" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_settings"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_settings_select" ON "public"."sandbox_settings" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_settings"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "sandbox_settings_update" ON "public"."sandbox_settings" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_settings"."org_id") AND ("m"."user_id" = "auth"."uid"()))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "sandbox_settings"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."user_settings" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "user_settings_delete" ON "public"."user_settings" FOR DELETE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "user_settings"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "user_settings_insert" ON "public"."user_settings" FOR INSERT WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "user_settings"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "user_settings_select" ON "public"."user_settings" FOR SELECT USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "user_settings"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



CREATE POLICY "user_settings_update" ON "public"."user_settings" FOR UPDATE USING ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "user_settings"."org_id") AND ("m"."user_id" = "auth"."uid"())))))) WITH CHECK ((("user_id" = "auth"."uid"()) AND (EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "user_settings"."org_id") AND ("m"."user_id" = "auth"."uid"()))))));



ALTER TABLE "public"."valuation_calibration_buckets" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_calibration_buckets_select" ON "public"."valuation_calibration_buckets" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_calibration_buckets_write" ON "public"."valuation_calibration_buckets" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



ALTER TABLE "public"."valuation_calibration_freezes" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_calibration_freezes_select" ON "public"."valuation_calibration_freezes" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_calibration_freezes_write" ON "public"."valuation_calibration_freezes" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



ALTER TABLE "public"."valuation_comp_overrides" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_comp_overrides_del" ON "public"."valuation_comp_overrides" FOR DELETE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_comp_overrides"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['owner'::"public"."membership_role", 'manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



CREATE POLICY "valuation_comp_overrides_ins" ON "public"."valuation_comp_overrides" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_comp_overrides"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['owner'::"public"."membership_role", 'manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



CREATE POLICY "valuation_comp_overrides_sel" ON "public"."valuation_comp_overrides" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_comp_overrides"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_comp_overrides_upd" ON "public"."valuation_comp_overrides" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_comp_overrides"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['owner'::"public"."membership_role", 'manager'::"public"."membership_role", 'vp'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_comp_overrides"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['owner'::"public"."membership_role", 'manager'::"public"."membership_role", 'vp'::"public"."membership_role"]))))));



ALTER TABLE "public"."valuation_eval_runs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_eval_runs_ins" ON "public"."valuation_eval_runs" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_eval_runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_eval_runs_sel" ON "public"."valuation_eval_runs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_eval_runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."valuation_ground_truth" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_ground_truth_ins" ON "public"."valuation_ground_truth" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_ground_truth"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



CREATE POLICY "valuation_ground_truth_sel" ON "public"."valuation_ground_truth" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_ground_truth"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_ground_truth_upd" ON "public"."valuation_ground_truth" FOR UPDATE USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_ground_truth"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_ground_truth"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



ALTER TABLE "public"."valuation_runs" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_runs_insert_in_org" ON "public"."valuation_runs" FOR INSERT WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_runs_select_in_org" ON "public"."valuation_runs" FOR SELECT USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "valuation_runs"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



ALTER TABLE "public"."valuation_weights" ENABLE ROW LEVEL SECURITY;


CREATE POLICY "valuation_weights_select" ON "public"."valuation_weights" FOR SELECT TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"())))));



CREATE POLICY "valuation_weights_write" ON "public"."valuation_weights" TO "authenticated" USING ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"])))))) WITH CHECK ((EXISTS ( SELECT 1
   FROM "public"."memberships" "m"
  WHERE (("m"."org_id" = "m"."org_id") AND ("m"."user_id" = "auth"."uid"()) AND ("m"."role" = ANY (ARRAY['manager'::"public"."membership_role", 'vp'::"public"."membership_role", 'owner'::"public"."membership_role"]))))));



GRANT USAGE ON SCHEMA "public" TO "postgres";
GRANT USAGE ON SCHEMA "public" TO "anon";
GRANT USAGE ON SCHEMA "public" TO "authenticated";
GRANT USAGE ON SCHEMA "public" TO "service_role";
GRANT USAGE ON SCHEMA "public" TO "authenticator";



GRANT ALL ON FUNCTION "public"."_ensure_policy_cmd"("_name" "text", "_table" "regclass", "_cmd" "text", "_using" "text", "_check" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."_ensure_policy_cmd"("_name" "text", "_table" "regclass", "_cmd" "text", "_using" "text", "_check" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."_ensure_policy_cmd"("_name" "text", "_table" "regclass", "_cmd" "text", "_using" "text", "_check" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."audit_log_row_change"() TO "anon";
GRANT ALL ON FUNCTION "public"."audit_log_row_change"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."audit_log_row_change"() TO "service_role";



GRANT ALL ON FUNCTION "public"."dbg_claim"("claim" "text") TO "anon";
GRANT ALL ON FUNCTION "public"."dbg_claim"("claim" "text") TO "authenticated";
GRANT ALL ON FUNCTION "public"."dbg_claim"("claim" "text") TO "service_role";



GRANT ALL ON FUNCTION "public"."dbg_uid"() TO "anon";
GRANT ALL ON FUNCTION "public"."dbg_uid"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."dbg_uid"() TO "service_role";



GRANT ALL ON FUNCTION "public"."debug_auth_context"() TO "anon";
GRANT ALL ON FUNCTION "public"."debug_auth_context"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."debug_auth_context"() TO "service_role";



GRANT ALL ON FUNCTION "public"."delete_expired_ai_chat"() TO "anon";
GRANT ALL ON FUNCTION "public"."delete_expired_ai_chat"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."delete_expired_ai_chat"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."ensure_membership_for_self_vp"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."ensure_membership_for_self_vp"() TO "anon";
GRANT ALL ON FUNCTION "public"."ensure_membership_for_self_vp"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."ensure_membership_for_self_vp"() TO "service_role";



GRANT ALL ON FUNCTION "public"."export_schema_ddl"() TO "anon";
GRANT ALL ON FUNCTION "public"."export_schema_ddl"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."export_schema_ddl"() TO "service_role";



REVOKE ALL ON FUNCTION "public"."get_caller_org"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."get_caller_org"() TO "anon";
GRANT ALL ON FUNCTION "public"."get_caller_org"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."get_caller_org"() TO "service_role";
GRANT ALL ON FUNCTION "public"."get_caller_org"() TO "authenticator";



GRANT ALL ON FUNCTION "public"."is_member_of"("p_org" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_member_of"("p_org" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_member_of"("p_org" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_org_manager"("p_org" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_org_manager"("p_org" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_org_manager"("p_org" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_org_manager"("_org" "uuid", "_uid" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_org_manager"("_org" "uuid", "_uid" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_org_manager"("_org" "uuid", "_uid" "uuid") TO "service_role";



GRANT ALL ON FUNCTION "public"."is_org_member"("_org" "uuid", "_uid" "uuid") TO "anon";
GRANT ALL ON FUNCTION "public"."is_org_member"("_org" "uuid", "_uid" "uuid") TO "authenticated";
GRANT ALL ON FUNCTION "public"."is_org_member"("_org" "uuid", "_uid" "uuid") TO "service_role";



REVOKE ALL ON FUNCTION "public"."pgrst_reload"() FROM PUBLIC;
GRANT ALL ON FUNCTION "public"."pgrst_reload"() TO "anon";
GRANT ALL ON FUNCTION "public"."pgrst_reload"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."pgrst_reload"() TO "service_role";



GRANT ALL ON FUNCTION "public"."publish_valuation_weights"("p_org_id" "uuid", "p_market_key" "text", "p_home_band" "text", "p_weights" "jsonb", "p_note" "text", "p_effective_at" timestamp with time zone) TO "anon";
GRANT ALL ON FUNCTION "public"."publish_valuation_weights"("p_org_id" "uuid", "p_market_key" "text", "p_home_band" "text", "p_weights" "jsonb", "p_note" "text", "p_effective_at" timestamp with time zone) TO "authenticated";
GRANT ALL ON FUNCTION "public"."publish_valuation_weights"("p_org_id" "uuid", "p_market_key" "text", "p_home_band" "text", "p_weights" "jsonb", "p_note" "text", "p_effective_at" timestamp with time zone) TO "service_role";



GRANT ALL ON FUNCTION "public"."runs_bi_fill"() TO "anon";
GRANT ALL ON FUNCTION "public"."runs_bi_fill"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."runs_bi_fill"() TO "service_role";



GRANT ALL ON FUNCTION "public"."set_created_by"() TO "anon";
GRANT ALL ON FUNCTION "public"."set_created_by"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."set_created_by"() TO "service_role";



GRANT ALL ON FUNCTION "public"."sha256_hex_jsonb"("j" "jsonb") TO "anon";
GRANT ALL ON FUNCTION "public"."sha256_hex_jsonb"("j" "jsonb") TO "authenticated";
GRANT ALL ON FUNCTION "public"."sha256_hex_jsonb"("j" "jsonb") TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_ai_chat_messages_fill"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_ai_chat_messages_fill"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_ai_chat_messages_fill"() TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_ai_chat_threads_bump"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_ai_chat_threads_bump"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_ai_chat_threads_bump"() TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_deal_contracts_immutable"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_deal_contracts_immutable"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_deal_contracts_immutable"() TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_deal_task_states_set_updated_by"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_deal_task_states_set_updated_by"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_deal_task_states_set_updated_by"() TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_deal_workflow_events_snapshot_overrides"() TO "service_role";



GRANT ALL ON FUNCTION "public"."tg_set_updated_at"() TO "anon";
GRANT ALL ON FUNCTION "public"."tg_set_updated_at"() TO "authenticated";
GRANT ALL ON FUNCTION "public"."tg_set_updated_at"() TO "service_role";



GRANT ALL ON TABLE "public"."organizations" TO "anon";
GRANT ALL ON TABLE "public"."organizations" TO "authenticated";
GRANT ALL ON TABLE "public"."organizations" TO "service_role";



GRANT ALL ON TABLE "public"."_default_org" TO "anon";
GRANT ALL ON TABLE "public"."_default_org" TO "authenticated";
GRANT ALL ON TABLE "public"."_default_org" TO "service_role";



GRANT ALL ON TABLE "public"."agent_runs" TO "anon";
GRANT ALL ON TABLE "public"."agent_runs" TO "authenticated";
GRANT ALL ON TABLE "public"."agent_runs" TO "service_role";



GRANT ALL ON TABLE "public"."ai_chat_messages" TO "anon";
GRANT ALL ON TABLE "public"."ai_chat_messages" TO "authenticated";
GRANT ALL ON TABLE "public"."ai_chat_messages" TO "service_role";



GRANT ALL ON TABLE "public"."ai_chat_threads" TO "anon";
GRANT ALL ON TABLE "public"."ai_chat_threads" TO "authenticated";
GRANT ALL ON TABLE "public"."ai_chat_threads" TO "service_role";



GRANT ALL ON TABLE "public"."audit_logs" TO "anon";
GRANT ALL ON TABLE "public"."audit_logs" TO "authenticated";
GRANT ALL ON TABLE "public"."audit_logs" TO "service_role";



GRANT ALL ON SEQUENCE "public"."audit_logs_id_seq" TO "anon";
GRANT ALL ON SEQUENCE "public"."audit_logs_id_seq" TO "authenticated";
GRANT ALL ON SEQUENCE "public"."audit_logs_id_seq" TO "service_role";



GRANT ALL ON TABLE "public"."deal_contracts" TO "anon";
GRANT ALL ON TABLE "public"."deal_contracts" TO "authenticated";
GRANT ALL ON TABLE "public"."deal_contracts" TO "service_role";



GRANT ALL ON TABLE "public"."deal_task_states" TO "anon";
GRANT ALL ON TABLE "public"."deal_task_states" TO "authenticated";
GRANT ALL ON TABLE "public"."deal_task_states" TO "service_role";



GRANT ALL ON TABLE "public"."deal_workflow_events" TO "anon";
GRANT ALL ON TABLE "public"."deal_workflow_events" TO "authenticated";
GRANT ALL ON TABLE "public"."deal_workflow_events" TO "service_role";



GRANT ALL ON TABLE "public"."deal_working_states" TO "anon";
GRANT ALL ON TABLE "public"."deal_working_states" TO "authenticated";
GRANT ALL ON TABLE "public"."deal_working_states" TO "service_role";



GRANT ALL ON TABLE "public"."deals" TO "anon";
GRANT ALL ON TABLE "public"."deals" TO "authenticated";
GRANT ALL ON TABLE "public"."deals" TO "service_role";



GRANT ALL ON TABLE "public"."evidence" TO "anon";
GRANT ALL ON TABLE "public"."evidence" TO "authenticated";
GRANT ALL ON TABLE "public"."evidence" TO "service_role";



GRANT ALL ON TABLE "public"."market_price_index" TO "anon";
GRANT ALL ON TABLE "public"."market_price_index" TO "authenticated";
GRANT ALL ON TABLE "public"."market_price_index" TO "service_role";



GRANT ALL ON TABLE "public"."memberships" TO "anon";
GRANT ALL ON TABLE "public"."memberships" TO "authenticated";
GRANT ALL ON TABLE "public"."memberships" TO "service_role";



GRANT ALL ON TABLE "public"."offer_packages" TO "anon";
GRANT ALL ON TABLE "public"."offer_packages" TO "authenticated";
GRANT ALL ON TABLE "public"."offer_packages" TO "service_role";



GRANT ALL ON TABLE "public"."policies" TO "anon";
GRANT ALL ON TABLE "public"."policies" TO "authenticated";
GRANT ALL ON TABLE "public"."policies" TO "service_role";



GRANT ALL ON TABLE "public"."policy_overrides" TO "anon";
GRANT ALL ON TABLE "public"."policy_overrides" TO "authenticated";
GRANT ALL ON TABLE "public"."policy_overrides" TO "service_role";



GRANT ALL ON TABLE "public"."policy_versions" TO "anon";
GRANT ALL ON TABLE "public"."policy_versions" TO "authenticated";
GRANT ALL ON TABLE "public"."policy_versions" TO "service_role";



GRANT ALL ON TABLE "public"."policy_versions_api" TO "anon";
GRANT ALL ON TABLE "public"."policy_versions_api" TO "authenticated";
GRANT ALL ON TABLE "public"."policy_versions_api" TO "service_role";



GRANT ALL ON TABLE "public"."property_snapshots" TO "anon";
GRANT ALL ON TABLE "public"."property_snapshots" TO "authenticated";
GRANT ALL ON TABLE "public"."property_snapshots" TO "service_role";



GRANT ALL ON TABLE "public"."repair_rate_sets" TO "anon";
GRANT ALL ON TABLE "public"."repair_rate_sets" TO "authenticated";
GRANT ALL ON TABLE "public"."repair_rate_sets" TO "service_role";



GRANT ALL ON TABLE "public"."runs" TO "anon";
GRANT ALL ON TABLE "public"."runs" TO "authenticated";
GRANT ALL ON TABLE "public"."runs" TO "service_role";



GRANT ALL ON TABLE "public"."runs_api" TO "anon";
GRANT ALL ON TABLE "public"."runs_api" TO "authenticated";
GRANT ALL ON TABLE "public"."runs_api" TO "service_role";



GRANT ALL ON TABLE "public"."runs_latest_per_fingerprint" TO "anon";
GRANT ALL ON TABLE "public"."runs_latest_per_fingerprint" TO "authenticated";
GRANT ALL ON TABLE "public"."runs_latest_per_fingerprint" TO "service_role";



GRANT ALL ON TABLE "public"."sandbox_presets" TO "anon";
GRANT ALL ON TABLE "public"."sandbox_presets" TO "authenticated";
GRANT ALL ON TABLE "public"."sandbox_presets" TO "service_role";



GRANT ALL ON TABLE "public"."sandbox_settings" TO "anon";
GRANT ALL ON TABLE "public"."sandbox_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."sandbox_settings" TO "service_role";



GRANT ALL ON TABLE "public"."user_settings" TO "anon";
GRANT ALL ON TABLE "public"."user_settings" TO "authenticated";
GRANT ALL ON TABLE "public"."user_settings" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_calibration_buckets" TO "anon";
GRANT ALL ON TABLE "public"."valuation_calibration_buckets" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_calibration_buckets" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_calibration_freezes" TO "anon";
GRANT ALL ON TABLE "public"."valuation_calibration_freezes" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_calibration_freezes" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_comp_overrides" TO "anon";
GRANT ALL ON TABLE "public"."valuation_comp_overrides" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_comp_overrides" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_eval_runs" TO "anon";
GRANT ALL ON TABLE "public"."valuation_eval_runs" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_eval_runs" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_ground_truth" TO "anon";
GRANT ALL ON TABLE "public"."valuation_ground_truth" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_ground_truth" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_runs" TO "anon";
GRANT ALL ON TABLE "public"."valuation_runs" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_runs" TO "service_role";



GRANT ALL ON TABLE "public"."valuation_weights" TO "anon";
GRANT ALL ON TABLE "public"."valuation_weights" TO "authenticated";
GRANT ALL ON TABLE "public"."valuation_weights" TO "service_role";



ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON SEQUENCES TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON FUNCTIONS TO "service_role";






ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "postgres";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "anon";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "authenticated";
ALTER DEFAULT PRIVILEGES FOR ROLE "postgres" IN SCHEMA "public" GRANT ALL ON TABLES TO "service_role";







