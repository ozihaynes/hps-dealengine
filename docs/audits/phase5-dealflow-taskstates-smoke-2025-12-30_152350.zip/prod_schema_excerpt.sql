-- Excerpt from PROD public schema dump (DealFlow tables)
\n-- CREATE TABLE public.deal_task_states
CREATE TABLE IF NOT EXISTS "public"."deal_task_states" (
    "id" "uuid" DEFAULT "gen_random_uuid"() NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "task_key" "text" NOT NULL,
    "override_status" "text" NOT NULL,
    "note" "text",
\n-- ENABLE ROW LEVEL SECURITY public.deal_task_states
ALTER TABLE "public"."deal_task_states" ENABLE ROW LEVEL SECURITY;
\n-- CREATE TABLE public.deal_workflow_events
CREATE TABLE IF NOT EXISTS "public"."deal_workflow_events" (
    "id" "uuid" NOT NULL,
    "org_id" "uuid" NOT NULL,
    "deal_id" "uuid" NOT NULL,
    "event_type" "public"."deal_workflow_event_type" NOT NULL,
    "run_id" "uuid" NOT NULL,
    "policy_hash" "text" NOT NULL,
\n-- ENABLE ROW LEVEL SECURITY public.deal_workflow_events
ALTER TABLE "public"."deal_workflow_events" ENABLE ROW LEVEL SECURITY;
