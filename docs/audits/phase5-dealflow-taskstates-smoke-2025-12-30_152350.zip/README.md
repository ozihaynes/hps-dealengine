# DealFlow task-states smoke audit

timestamp: 2025-12-30 17:09:29
project_ref: zjkihnihhqmnhpxkecpy
deal_id: f84bab8d-e377-4512-a4c8-0821c23a82ea

Proof:
- DB schema dump includes DealFlow tables with RLS enabled
- v1-deal-task-states called twice (deterministic hash match)

Artifacts:
- prod_schema_excerpt.sql
- dealflow_migration_hits.txt
- dealflow_expected_tables.txt
- prod_schema_verification.txt
- functions_list_prod.txt
- response1.json
- response2.json
- hashes.txt
