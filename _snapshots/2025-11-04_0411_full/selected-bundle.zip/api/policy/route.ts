import { NextRequest, NextResponse } from "next/server";
import * as Contracts from "@hps-internal/contracts";
import { promises as fs } from "fs";
import path from "path";

export const runtime = "nodejs";

const DATA_DIR = path.join(process.cwd(), ".data");
const FILE = (posture: Contracts.Posture) => path.join(DATA_DIR, `policy.${posture}.json`);

async function ensureDir() {
  await fs.mkdir(DATA_DIR, { recursive: true });
}

export async function GET(req: NextRequest) {
  const posture = (req.nextUrl.searchParams.get("posture") ?? "base") as Contracts.Posture;
  await ensureDir();
  try {
    const raw = await fs.readFile(FILE(posture), "utf8");
    const parsed = JSON.parse(raw);
    // Validate with the contracts schema
    const policy = Contracts.SettingsSchema.parse(parsed);
    return NextResponse.json({ policy });
  } catch {
    // Fallback to defaults when file is missing or invalid
    return NextResponse.json({ policy: Contracts.policyDefaults[posture] });
  }
}

export async function PUT(req: NextRequest) {
  const posture = (req.nextUrl.searchParams.get("posture") ?? "base") as Contracts.Posture;
  const body = await req.json();
  const candidate = { posture, ...body };
  // Validate & coerce before writing
  const policy = Contracts.SettingsSchema.parse(candidate);
  await ensureDir();
  await fs.writeFile(FILE(posture), JSON.stringify(policy, null, 2), "utf8");
  return NextResponse.json({ policy });
}
