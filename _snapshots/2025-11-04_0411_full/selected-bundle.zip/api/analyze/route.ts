// apps/hps-dealengine/app/api/analyze/route.ts
import { NextRequest, NextResponse } from "next/server";
import path from "path";
import { promises as fs } from "fs";

// contracts: posture + minimal policy (tokens + metadata)
import * as Contracts from "@hps-internal/contracts";

// engine: deterministic underwriting
import { computeUnderwriting } from "@hps-internal/engine";

export const runtime = "nodejs";

// local policy storage (same pattern as /api/policy)
const DATA_DIR = path.join(process.cwd(), ".data");
const POLICY_FILE = (posture: Contracts.Posture) =>
  path.join(DATA_DIR, `policy.${posture}.json`);

async function loadPolicy(posture: Contracts.Posture): Promise<Contracts.Settings> {
  await fs.mkdir(DATA_DIR, { recursive: true });
  try {
    const raw = await fs.readFile(POLICY_FILE(posture), "utf8");
    const parsed = JSON.parse(raw);
    // validate against contracts package
    return Contracts.SettingsSchema.parse(parsed);
  } catch {
    // fallback to defaults
    return Contracts.policyDefaults[posture];
  }
}

// small helper: resolve tokens against a deal/policy payload
function applyTokens(
  deal: any,
  policy: Contracts.Settings
): { deal: any; policy: Contracts.Settings; tokens: Record<string, string> } {
  const tokens = policy.tokens ?? {};
  // for now we just pass them through; real engine can map <...> → numeric later
  // we return them in response so the UI can see exactly what we used
  return { deal, policy, tokens };
}

export async function POST(req: NextRequest) {
  // posture=... (conservative|base|aggressive)
  const postureParam = (req.nextUrl.searchParams.get("posture") ??
    "base") as Contracts.Posture;

  // 1) get caller's deal payload
  let body: any;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "BAD_JSON",
          message: "Request body must be valid JSON",
        },
      },
      { status: 400 }
    );
  }

  // expect { deal: {...} } for now
  const deal = body?.deal ?? {};

  // 2) load policy from local data store
  const policy = await loadPolicy(postureParam);

  // 3) attach tokens
  const { tokens } = applyTokens(deal, policy);

  // 4) call engine (deterministic)
  // NOTE: your engine signature is already used in the project; we call it the same way.
  // If your computeUnderwriting expects (deal, policy), this matches it.
  let engineResult: any;
  try {
    engineResult = await computeUnderwriting(deal, policy);
  } catch (err: any) {
    // if engine blows up, return a structured error so UI can show "INFO NEEDED"
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "ENGINE_ERROR",
          message: err?.message ?? "Engine failed",
        },
        debug: {
          posture: postureParam,
          policy,
          tokens,
        },
      },
      { status: 500 }
    );
  }

  // 5) respond with engine output + debug
  return NextResponse.json({
    ok: true,
    posture: postureParam,
    result: engineResult,
    debug: {
      policy,
      tokens,
    },
  });
}
