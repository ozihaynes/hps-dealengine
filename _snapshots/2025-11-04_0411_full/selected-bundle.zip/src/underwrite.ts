// Re-exports the main compute function with a stable name.
export { computeUnderwriting } from './compute_underwriting.js';
