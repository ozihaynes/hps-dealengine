Snapshot: diag_20251105_183328
Root:  C:\Users\oziha\Documents\hps-dealengine

Files:
  01_env_toolchain.txt       – Versions & binary paths
  02_git_state.txt           – Branch, status, commits, tags, stashes, reflog
  03_workspace_topology.txt  – pnpm workspaces & graph
  04_packages_json.txt       – Root/app/engine/contracts package.json
  05_configs_contracts.txt   – nvmrc, ignores, openapi (head)
  06_vercel_meta.txt         – .vercel local project metadata
  07_supabase.txt            – supabase status & functions list (+config)
  08_app_tree.txt            – apps/hps-dealengine file table
  09_api_routes.txt          – app/api route handlers
  10_local_data.txt          – .data contents (tokens/policy/prefs)
  11_tsconfigs.txt           – TypeScript configs
  12_env_redacted.txt        – .envs with values masked
  13_local_checks.txt        – typecheck/build(test) logs (engine-only)
  14_lock_suspects.txt       – running node/etc + .next dirs
